<?php
class Naya_OpenGraph_Helper_Data extends Mage_Core_Helper_Abstract {
    
    
}
