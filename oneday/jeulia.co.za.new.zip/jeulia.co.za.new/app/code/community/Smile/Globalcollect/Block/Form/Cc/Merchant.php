<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */


class Smile_Globalcollect_Block_Form_Cc_Merchant extends Mage_Payment_Block_Form_Cc
{

    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('globalcollect/form/cc/merchant.phtml');
    }

    /**
     * Retrieve avaible payment products by method
     *
     * @return array|boolean
     */
    public function getPaymentProducts()
    {
        if ($this->getMethod()) {
            return  $this->getMethod()
                    ->getPaymentProducts()
                    ->getItemsByColumnValue('payment_method_id', Mage::helper('globalcollect')->getCreditCardMethodId());
        }

        return false;
    }

    /**
     * Check selection for payment product
     *
     * @param Varien_Object $paymentProduct
     * @return boolean
     */
    public function isSelected($paymentProduct)
    {
        if ($this->getMethod()) {
            $selectedToken = $this->getMethod()->getSelectedToken()
                && $this->getMethod()->getSelectedToken()->getId() == $paymentProduct->getId();
            $selectedProduct = $this->getMethod()->getSelectedPaymentProduct()
                && $this->getMethod()->getSelectedPaymentProduct()->getId() == $paymentProduct->getId();
        }

        return $selectedToken || $selectedProduct;
    }

    /**
     * Get CC Last 4 Number from selected token
     *
     * @return string
     */
    public function getCcNumber()
    {
        if ($this->getMethod() && $this->getMethod()->getSelectedToken()) {
            return $this->getMethod()->getSelectedToken()->getCcNumber();
        }

        return '';
    }

    /**
     * Get Selected Card type
     *
     * @return int
     */
    public function getSelectedCardType()
    {
        if ($this->getMethod() && $this->getMethod()->getSelectedPaymentProduct()) {
            return $this->getMethod()->getSelectedPaymentProduct()->getId();
        }

        return 0;
    }

    public function getSelectedToken()
    {
        if ($this->getMethod()) {
            return $this->getMethod()->getSelectedToken();
        }

        return false;
    }

        /**
     * Retrive has verification configuration
     *
     * @return boolean
     */
    public function hasVerification()
    {
        if ($this->getMethod()) {
            $configData = $this->_getConfig()->getField('use_cvv');
            if(is_null($configData)){
                return true;
            }
            return (bool) $configData;
        }
        return true;
    }

    /**
     * Retrieve global collect config model
     *
     * @return Smile_Globalcollect_Model_Config
     */
    protected function _getConfig()
    {
        if ($this->_config === null) {
            $this->_config = Mage::getSingleton('globalcollect/config');
        }

        return $this->_config;
    }

    public function shouldShowSaveCc()
    {
        return Mage::getSingleton('customer/session')->isLoggedIn()
        && (bool) $this->getMethod()->getModuleConfigData('save_cards');
    }

    public function hideSaveCc()
    {
        return (bool)$this->getMethod()->getSelectedToken();
    }

}
