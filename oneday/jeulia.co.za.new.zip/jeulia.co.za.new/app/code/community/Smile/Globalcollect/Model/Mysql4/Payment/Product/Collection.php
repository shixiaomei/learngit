<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material 
 * are the property of their respective owners This software is not intended 
 * to be a complete solution of all applicable rules, policies and procedures. 
 * The matters referenced are subject to change from time to time, and 
 * individual circumstances may vary. Global Collect Services B.V. shall not 
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality 
 * of the software but makes no warranties or representations about the accuracy 
 * or completeness of it. Neither Global Collect Services B.V. nor any of its 
 * affiliates shall be liable for any costs, losses and/or damages arising out 
 * of access to or use of this software. Because of the complexity of the process 
 * and the right of Banks to alter conditions, this software can only serve 
 * as a quick-start in development is subject to further modifications.
 * 
 * The Magento extension was developed as a generic solution. 
 * In the event that the cartridge is modified by a user in any way, 
 * Global Collect Services B.V. shall not be responsible for any damages that 
 * are caused by the modified extension. Global Collect Services B.V. makes 
 * no warranties or representations about the use or operation of the extension. 
 * Neither Global Collect Services B.V. nor any of its affiliates shall be 
 * liable for any costs, losses and/or damages arising out of access to 
 * or use of the extension.
 * 
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to 
 * global.partnerships@globalcollect.com
 *  
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment products collection
 *
 */
class Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection extends Smile_Globalcollect_Model_Mysql4_Payment_Collection_Abstract
{
    protected function _construct()
    {
        $this->_init('globalcollect/payment_product');
    }
    
    /**
     * Adds method codes to select
     * 
     * @return \Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function addMethodsToSelect()
    {
        $this->join(
            array('pmethod_table' => 'globalcollect/payment_method'),
            'pmethod_table.payment_method_id = main_table.payment_method_id',
            array('method_code' => 'pmethod_table.code', 'method_name' => 'pmethod_table.name')
        );
        return $this;
    }
    
    /**
     * Filters by method
     * 
     * @param string $methodName Name
     * @return \Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function addMethodToFilter($methodName)
    {
        $this->addMethodsToSelect();
        $this->addFieldToFilter('pmethod_table.code', $methodName);
        return $this;
    }

    /**
     * Add scope (country, product) to payment products select
     *
     * @param string $countryId
     * @param string $currencyCode
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function addScopeToSelect($countryId, $currencyCode = null)
    {
        $parts = $this->getSelect()->getPart(Zend_Db_Select::FROM);
        if (isset($parts['scope_table'])) {
            return $this;
        }

        $conditions = array(
            'payment_product_id' => 'payment_product_id',
            'country_id' => array('eq' => $countryId),
        );
        if ($currencyCode) {
            $conditions['currency_code'] = array('eq' => $currencyCode);
        }

        $joinCondition = array();

        foreach ($conditions as $column => $condition) {
            if (!is_string($column)) {
                $column = $condition;
            }

            $column = $this->getConnection()->quoteIdentifier('scope_table.' . $column);
            if (is_string($condition)) {
                $join = $column . ' = ' .$this->getConnection()->quoteIdentifier('main_table.' . $condition);
            } else {
                $join = $this->_getConditionSql($column, $condition);
            }

            $joinCondition[] = $join;
        }

        $idFieldName = $this->getResource()->getIdFieldName();
        $this->getSelect()->joinLeft(
            array('scope_table' => $this->getResource()->getScopeTable()),
            implode(' AND ', $joinCondition),
            array('country_id', 'currency_code', 'minimum_amount', 'maximum_amount', 'order_type')
        );

        return $this;
    }

    /**
     * Set scope filer for collection, also applicable to apply allowed amount and order type filter
     *
     * @param string $countryId
     * @param string $currencyCode
     * @param float $amount
     * @param int $orderType
     */
    public function setScopeFilter($countryId, $currencyCode, $amount = null, $orderType = null)
    {
        $this->addScopeToSelect($countryId, $currencyCode);
        $this->getSelect()->where('scope_table.country_id IS NOT NULL');

        // @TODO: convert $amount to methods curency
//        if ($amount !== null) {
//            $this->getSelect()->where('(scope_table.minimum_amount IS NULL OR scope_table.minimum_amount <= ?)', $amount);
//            $this->getSelect()->where('(scope_table.maximum_amount IS NULL OR scope_table.maximum_amount >= ?)', $amount);
//        }

        if ($orderType !== null) { // Add order type bitmask filter
            $this->getSelect()->where('(scope_table.order_type & ' . (int) $orderType . ') = ' . (int) $orderType);
        }

        return $this;
    }

    /**
     * Set payment product filter
     *
     * @param Smile_Globalcollect_Model_Payment_Method|int $paymentMethod
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function setPaymentMethodFilter($paymentMethod)
    {
        if ($paymentMethod instanceof Smile_Globalcollect_Model_Payment_Method) {
            $paymentMethodId = $paymentMethod->getId();
        } elseif (is_array($paymentMethod)) {
            if (empty($paymentMethod)) {
                $paymentMethod[] = 0;
            }
            $paymentMethodId = array('in' => $paymentMethod);
        } else {
            $paymentMethodId = (int) $paymentMethod;
        }

        $this->addFieldToFilter('payment_method_id', $paymentMethodId);
        return $this;
    }
//    
//    public function addPaymentMethodFilter()
//    {
//        $this->join(array('methods_table'=> $this->getTable('payment_product')), array());
//    }
}
