<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Admin controller for globalcollect payment method actions
 *
 *
 */
class Smile_Globalcollect_Adminhtml_MethodController extends Mage_Adminhtml_Controller_Action
{

    protected function _initOrder()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        if ($orderId) {
            /**
             * @var $order Mage_Sales_Model_Order
             */
            $order = Mage::getModel('sales/order')->load($orderId);
            if (!$order->getId()) {
                $order = Mage::getModel('sales/order')->loadByIncrementId($orderId);
            }
            if ($order->getId()) {//$order->getPayment()->getMethodInstance() instanceof Smile_Globalcollect_Model_Method_Abstract) {
                Mage::register('globalcollect_current_order', $order);
                return $order;
            }
        }

        return false;
    }

    /**
     * Test connection to global collect
     *
     */
    public function testAction()
    {
        try {
            $result = Mage::getSingleton('globalcollect/api')
                ->testConnection($this->getRequest()->getParam('merchant_id'), $this->getRequest()->getParam('gateway_url'));
            if ($result) {
                $this->_getSession()->addSuccess(
                    Mage::helper('globalcollect')->__('Connection to GlobalCollect gateway successfully established')
                );
            } else {
                $this->_getSession()->addError(Mage::helper('globalcollect')->__('Unable to connect to GlobalCollect gateway'));
            }
        } catch (Exception $e) {
            $this->_getSession()->addException(
                $e,
                Mage::helper('globalcollect')->__('Unable to connect to GlobalCollect gateway')
            );
        }
        $this->loadLayout();
        $this->getResponse()->setBody($this->getLayout()->getMessagesBlock()->toHtml());
    }

    /**
     * Test connection to global collect
     *
     */
    public function getPaymentProductsAction()
    {
        try {
            Mage::getModel('globalcollect/payment')
                ->clearPaymentProducts()
                ->retreivePaymentProducts();
            $this->_getSession()->addSuccess(
                $this->__("Payment Methods successfully updated. %s Refresh %s page to see changes",
                    "<a href='' onclick='window.location.reload()'>", "</a>"
                )
            );
        } catch (Smile_Globalcollect_Exception $e) {
            $this->_getSession()->addError($e->getMessage());
        }

        $this->loadLayout();
        $this->getResponse()->setBody($this->getLayout()->getMessagesBlock()->toHtml());


    }

    public function acceptfraudAction()
    {
        $order = $this->_initOrder();
        if (!$order) {
            $this->norouteAction();
            return;
        }

        try {
            $order->getPayment()->getMethodInstance()->processFraudChallenged();
            $order->save();
        } catch (Mage_Core_Exception $e) {
            $this->_getSession()->addError($e->getMessage());
        } catch (Exception $e) {
            Mage::logException($e);
            $this->_getSession()->addError(Mage::helper('globalcollect')->__('Unable to process fraud order'));
        }

        $this->_redirect('adminhtml/sales_order/view', array('order_id' => $order->getId()));
    }

    /**
     * Redirect to orders list / order view page depends of the order status
     *
     * @return void
     */
    public function redirectAction()
    {
        $order = $this->_initOrder();
        $session = Mage::getSingleton('adminhtml/session');
        if ($order) {
            Mage::getSingleton('adminhtml/session')->addSuccess($this->__('The order has been created.'));
            try {
                $order->getPayment()->getMethodInstance()->processReturned();
                Mage::getSingleton('adminhtml/session')->addSuccess($this->__('Payment processed.'));
                $this->_iframeRedirect('adminhtml/sales_order/view', array('order_id' => $order->getId()));

            } catch (Smile_Globalcollect_Exception $e) {
                $session->addError($e->getMessage());
                $this->_iframeRedirect('adminhtml/sales_order');
            }
        } else {
            $session->addError($this->__("Unknown payment error"));
            $this->_iframeRedirect('adminhtml/sales_order');
        }
    }

    /**
     * Render redirect block
     *
     * @param string $path      Url path
     * @param array  $arguments Url parameters
     *
     * @return void
     */
    protected function _iframeRedirect($path, $arguments = array())
    {
        $block = $this->getLayout()->createBlock('core/template')
                    ->setTemplate('globalcollect/iframe_return.phtml')
                    ->setRedirectUrl(Mage::helper('adminhtml')->getUrl($path, $arguments));

        $this->getResponse()->setBody($block->toHtml());
    }
}
