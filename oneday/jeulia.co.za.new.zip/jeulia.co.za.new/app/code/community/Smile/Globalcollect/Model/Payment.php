<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment object for manipulations with internal globalcollect data
 *
 */

/**
 * @method Smile_Globalcollect_Model_Mysql4_Payment getResource()
 */

class Smile_Globalcollect_Model_Payment extends Mage_Core_Model_Abstract
{    
    /** realTimeBank order timeout in hrs
     */
    const PEDNING_EXPIRE_PERIOD = 2;

    /**
     * Global collect payment API model
     *
     * @var Smile_Globalcollect_Model_Api
     */
    protected $_api = null;

    /**
     * Current placing order
     *
     * @var Mage_Sales_Model_Order
     */
    protected $_currentPlacingOrder = null;

    protected function _construct()
    {
        $this->_init('globalcollect/payment');
    }

    /**
     * Retrieve global collect config model
     *
     * @return Smile_Globalcollect_Model_Config
     */
    protected function _getConfig()
    {
        return Mage::getSingleton('globalcollect/config');
    }

    /**
     * Retrieve Global Collect API model
     *
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _getApi()
    {
        if ($this->_api === null) {
            $this->_api = Mage::getSingleton('globalcollect/api');
        }

        return $this->_api;
    }
    
    /**
     * Set current placing order from observer,
     * for workaround of core issue with order place url
     *
     * @param Mage_Sales_Model_Order $order
     * @return Smile_Globalcollect_Model_Payment
     */
    public function setCurrentPlacingOrder($order)
    {
        $this->_currentPlacingOrder = $order;
        return $this;
    }
    
    /**
     * Retrieve current placing order to handle redirection url
     *
     *  @return Mage_Sales_Model_Order|null
     */
    public function getCurrentPlacingOrder()
    {
        return $this->_currentPlacingOrder;
    }

    /**
     * Retrieve language code from different sources
     *
     * @param string|Mage_Core_Model_Locale|Zend_Locale|null $language
     * @return string;
     */
    protected function _getLanguage($language = null)
    {
        if ($language === null) {
            $language = Mage::app()->getLocale()->getLocale()->getLanguage();
        } elseif ($language instanceof Mage_Core_Model_Locale) {
            $language = $language->getLocale()->getLanguage();
        } elseif ($language instanceof Zend_Locale) {
            $language = $language->getLanguage();
        }

        $language = strtolower($language);
        return $language;
    }

    /**
     * Retrieve payment methods
     *
     * @param string|boolean $language
     * @param Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection|array $paymentProducts
     */
    public function getPaymentMethods($language = null, $paymentProducts = null)
    {
        $language = $this->_getLanguage($language);

        $collection = $this->getPaymentMethodCollection();
        return $collection;
    }

    /**
     * Retrieve payment products
     *
     * @param Smile_Globalcollect_Model_Method_Abstract $method
     * @param decimal $amount
     * @param int $orderType
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function getPaymentProducts($method, $amount = null, $orderType = null)
    {
        $countryId = $method->getCountryId();
        $collection = $this->getPaymentProductCollection();


        $collection->setScopeFilter($countryId, /*$currencyCode*/null, $amount, $orderType);
        return $collection;
    }

    /**
     * Retrieve payment product fields
     *
     * @param Smile_Globalcollect_Model_Method_Abstract $method
     * @param int $paymentProductId
     * @param string $language
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Field_Collection
     */
    public function getPaymentProductFields($paymentProduct, $required_only = true)
    {
        // Not used for now
        return false;


        if ($required_only) {
            if ($paymentProduct->hasRequiredFilds()) {
                /* @TODO: get stored fields.
                 * Hardcoded for now for DirectDebit only
                 */
                return array(
                    array('label' => 'Direct Debit Text', 'name' => 'DIRECTDEBITTEXT', 'type' => 'text'),
                );
            }
        }

    }



    /**
     * Retrieve payment method collection instance
     *
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Method_Collection
     */
    public function getPaymentMethodCollection()
    {
        return Mage::getResourceModel('globalcollect/payment_method_collection')
            ->addSortById();
    }

    /**
     * Retrieve payment product collection instance
     *
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function getPaymentProductCollection()
    {
        return Mage::getResourceModel('globalcollect/payment_product_collection')
            ->addSortById();
    }


    /**
     * Find node by key from result list
     *
     * @param array $list
     * @param string $key
     * @param int|string $value
     * @return Varien_Simplexml_Element|boolean
     */
    protected function _findNodeByKey($list, $key, $value)
    {
        foreach ($list as $node) {
            $nodeValue = $node->descend($key);
            if (is_int($value)) {
                $nodeValue = (int) $nodeValue;
            } else {
                $nodeValue = (string) $nodeValue;
            }

            if ($nodeValue === $value) {
                return $node;
            }
        }

        return false;
    }


    /**
     * Check is order sent to globalcollect
     *
     * @param string $incrementId
     * @return boolean
     */
    public function isOrderSent($incrementId)
    {
        return $this->getResource()->isOrderSent($incrementId);
    }

    /**
     * Check is order processed after any pending state from globalcollect
     *
     * @param string $incrementId
     * @return boolean
     */
    public function isOrderProcessed($incrementId)
    {
        return $this->getResource()->isOrderProcessed($incrementId);
    }

    /**
     * Set order as sent to global collect
     *
     * @param string $incrementId
     * @return Smile_Globalcollect_Model_Payment
     */
    public function setOrderSent($incrementId)
    {
        if ($this->isOrderSent($incrementId)) {
            $this->throwException(Mage::helper('globalcollect')->__('Order #%s already sent to GlobalCollect gateway'));
        }

        $this->getResource()->setOrderSent($incrementId);
        return $this;
    }

    /**
     * Add order attempt count for handling unset of reserved_increment_id
     *
     * @param string $incrementId
     * @return Smile_Globalcollect_Model_Payment
     */
    public function addOrderAttempt($incrementId)
    {
        if (!$this->isOrderSent($incrementId)) {
            $this->throwException(Mage::helper('globalcollect')->__('Order # %s wasn\'t send to GlobalCollect gateway', $incrementId));
        }

        $this->getResource()->addOrderAttempt($incrementId);
        return $this;
    }

    /**
     * Retrieve order attempt count
     *
     * @param string $incrementId
     * @return int
     */
    public function getOrderAttemptCount($incrementId)
    {
        return $this->getResource()->getOrderAttemptCount($incrementId);
    }

    /**
     * Set order as processed after redirection from global collect
     *
     * @param string|array $incrementId
     * @param boolean $isProcessed
     * @return Smile_Globalcollect_Model_Payment
     */
    public function setOrderProcessed($incrementId, $isProcessed = true)
    {
        $this->getResource()->setOrderProcessed($incrementId, $isProcessed);
        return $this;
    }

    /**
     * Set order as pending for further processing using daily reports
     *
     * @param string|array $incrementId
     * @param boolean $isProcessed
     * @return Smile_Globalcollect_Model_Payment
     */
    public function setOrderPending($incrementId, $isPending = false)
    {
        $this->getResource()->setOrderPending($incrementId);
        return $this;
    }


    /**
     * Set order as checked after batch process creation
     *
     * @param string|array $incrementId
     * @return Smile_Globalcollect_Model_Payment
     */
    public function setOrderCheckedAt($incrementId)
    {
        $this->getResource()->setOrderCheckedAt($incrementId);
        return $this;
    }


    /**
     * Thorws global collect exception
     *
     * @param string $message
     * @throws Smile_Globalcollect_Exception
     */
    public function throwException($message)
    {
        throw Mage::exception('Smile_Globalcollect', $message);
    }

    /**
     * Retrieves order ids for batch process
     * depends on system configuration limits
     *
     * @return array
     */
    public function getOrderIdsForBatch()
    {
        return $this->getResource()->getSentOrderIncrementIds(self::PEDNING_EXPIRE_PERIOD);
    }

    /**
     * Retrieves order ids for batch process using daily reports
     * depends on system configuration limits
     *
     * @return array
     */
    public function getOrderIdsForWR()
    {
        $expiry = $this->_getConfig()->getField('order_expire');

        return $this->getResource()->getPendingOrderIncrementIds($expiry);
    }
    
    /**
     * Get All pending orders
     * 
     * @return array 
     */
    public function getOrdersForCleanup()
    {
        return $this->getResource()->getAllPendingOrders();
    }
    

    /**
     * Flush all payment products info
     *
     * @return Smile_Globalcollect_Model_Payment
     */
    public function clearPaymentProducts()
    {
        $this->getResource()->clearPaymentProducts();
        return $this;
    }

    /**
     * Fetches payment products from global collect and stores to database
     * fills payment products, payment methods and scope tables
     *
     */
    public function retreivePaymentProducts($country = null, $currency = null, $language = 'en')
    {
        if (!$country) {
            foreach ($this->_getConfig()->getAllowedCountries() as $country) {
                $this->retreivePaymentProducts($country);
            }
        } else {
                $currency = Mage::app()->getWebsite()->getBaseCurrencyCode();

                $methodLocale = new Varien_Object(array(
                    'country_code' => $country,
                    'language_code' => $language,
                    'currency_code' => $currency
                    ));
                $response = $this->_getApi()->call(Smile_Globalcollect_Model_Api::ACTION_GET_PAYMENT_PRODUCTS, $methodLocale);

                if ($this->_getApi()->isResponseSuccessfull($response)) {
                    $items = $this->_getApi()->getResponseItem($response, 'ROW', true, true);

//                    // unset scopes for payment products
//                    foreach ($this->getPaymentProductCollection() as $product) {
//                        if (!$this->_findNodeByKey($items, 'PAYMENTPRODUCTID', $product->getId())
//                                && $product->hasScope($country)) {
//                            $product->unsetScope($country);
//                        }
//                    }

                    //add new products and scopes
                    foreach ($items as $node) {
                        $product_id = (int)$node->PAYMENTPRODUCTID;

                        // add new payment product if not exists
                        $paymentProduct = Mage::getModel('globalcollect/payment_product')->load($product_id);
                        if (!$paymentProduct->getId()) {
                            $paymentMethodCode = Mage::helper('globalcollect')->formatMethodCode((string)$node->PAYMENTMETHODNAME);
                            $paymentMethod = Mage::getModel('globalcollect/payment_method')->loadByCode($paymentMethodCode);
                            if (!$paymentMethod->getId()) {
                                $paymentMethod->setCode($paymentMethodCode)
                                        ->setName((string)$node->PAYMENTMETHODNAME)
                                        ->save();
                            }

                            $paymentProduct->setId($product_id)
                                    ->setCode((string)$node->PAYMENTPRODUCTNAME)
                                    ->setPaymentMethodId($paymentMethod->getId())
                                    ->save();
                        }

                        // save scope for this method
                        $paymentProduct
                            ->setCountryId($country)
                            ->setCurrencyCode($currency)
                            ->import($node);
                    }
                } else {
                    $message = $this->_getApi()->getResponseErrorMessage($response);
                    if ($this->_getApi()->getResponseErrorCode($response) == 21000080) {
                        // NOT VALID COUNTRYCODE
                        // continue
                        Mage::log("API ERROR: ".$message, 0);
                    } else {
                        $this->throwException("API ERROR: ".$message);
                    }
                }
        }
    }
}
