<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment data manipulation resource model
 *
 */
class Smile_Globalcollect_Model_Mysql4_Payment extends Mage_Core_Model_Mysql4_Abstract
{
    const SENT_ORDER_STATUS      = 0;
    const PROCESSED_ORDER_STATUS = 1;
    const PENDING_ORDER_STATUS   = 2;


    protected function _construct()
    {
        $this->_setResource('globalcollect');
    }

    /**
     * Retrieve order sent table
     *
     * @return string
     */
    public function getOrderSentTable()
    {
        return $this->getTable('globalcollect/order_sent');
    }


    /**
     * Add order attempt count for handling unset of reserved_increment_id
     *
     * @param string $incrementId
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function addOrderAttempt($incrementId)
    {
        $safeOrderId = preg_replace('/[^0-9]/', '', $incrementId);
        $this->_getWriteAdapter()->update(
            $this->getOrderSentTable(),
            array(
                'attempt_count' => new Zend_Db_Expr('attempt_count + 1')
            ),
            $this->_getWriteAdapter()->quoteInto('order_id = ?', $safeOrderId)
        );
        return $this;
    }

    /**
     * Retrieve order attempt count
     *
     * @param string $incrementId
     * @return int
     */
    public function getOrderAttemptCount($incrementId)
    {
        $select = $this->_getReadAdapter()->select()
            ->from($this->getOrderSentTable(), 'attempt_count')
            ->where('increment_id = ?', $incrementId);

        return (int) $this->_getReadAdapter()->fetchOne($select);
    }

    /**
     * Check is order sent to globalcollect
     *
     * @param string $incrementId
     * @return boolean
     */
    public function isOrderSent($incrementId)
    {
        $select = $this->_getReadAdapter()->select()
            ->from($this->getOrderSentTable(), 'COUNT(increment_id)')
            ->where('increment_id = ?', $incrementId);
        return $this->_getReadAdapter()->fetchOne($select) > 0;
    }

    /**
     * Check is order processed
     *
     * @param string $incrementId
     * @return boolean
     */
    public function isOrderProcessed($incrementId)
    {
        $select = $this->_getReadAdapter()->select()
            ->from($this->getOrderSentTable(), 'processed')
            ->where('increment_id = ?', $incrementId);
        return $this->_getReadAdapter()->fetchOne($select) > 0;
    }

    /**
     * Retrieve sent order ids for further processing
     *
     * @param int $period period of between order checks (in hours)
     * @param array $orderIds
     * @param boolean $asExpr idicates that result should be a zend db expr
     * @return array|Zend_Db_Expr
     */
    public function getSentOrderIncrementIds($period = 0, $limit = null, $orderIds = null, $asExpr = false)
    {
        $period = $this->_getReadAdapter()->quote($period, Zend_Db::INT_TYPE);
        $select = $this->_getReadAdapter()->select()
            ->from(array('order_sent' => $this->getOrderSentTable()), array(
                    'increment_id',
                    'expired' => 'DATE_ADD(IFNULL(order_sent.checked_at, order_sent.created_at), INTERVAL ' . $period . " HOUR) < '".now()."'",
                    ))
            ->where('order_sent.processed = ?', self::SENT_ORDER_STATUS);

        if (is_array($orderIds)) {
            if (empty($orderIds)) {
                $orderIds = array('');
            }

            $select->where('order_sent.order_id IN(?)', $orderIds);
        }

        if ($limit !== null) {
            $select->limit($limit);
            // If we have limit, we should process not checked and old orders first
            $select->order('order_sent.checked_at ASC');
        }

        if (!$asExpr) {
            return $this->_getReadAdapter()->fetchAll($select);
        }

        return new Zend_Db_Expr($select->assemble());
    }

    /**
     * Retrieve sent order ids for further processing
     *
     * @param int $period period of between order checks (in hours)
     * @param boolean $asExpr idicates that result should be a zend db expr
     * @return array|Zend_Db_Expr
     */
    public function getPendingOrderIncrementIds($period, $asExpr = false)
    {
        $period = $this->_getReadAdapter()->quote($period, Zend_Db::INT_TYPE);
        $select = $this->_getReadAdapter()->select()
            ->from(array('order_sent' => $this->getOrderSentTable()), array(
                    'increment_id',
                    'expired' => 'DATE_ADD(order_sent.created_at, INTERVAL ' . $period . " HOUR) < '".now()."'",
                    'test_mode'
                    ))
            ->where('order_sent.processed = ?', self::PENDING_ORDER_STATUS);

        if (!$asExpr) {
            return $this->_getReadAdapter()->fetchAll($select);
        } else {
            return new Zend_Db_Expr($select->assemble());
        }
    }
    
    /**
     * Get all pending orders
     * 
     * @return array 
     */
    public function getAllPendingOrders()
    {
        $select = $this->_getReadAdapter()->select()
            ->from($this->getOrderSentTable(), array(
                    'increment_id',
                    'created_at',
                    ))
            ->where('processed in (?)', array(self::SENT_ORDER_STATUS, self::PENDING_ORDER_STATUS));
        
        return $this->_getReadAdapter()->fetchAll($select);
    }

    /**
     * Set order is sent to global collect gateway
     *
     * @param string $incrementId
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function setOrderSent($incrementId)
    {
        $safeOrderId = preg_replace('/[^0-9]/', '', $incrementId);
        $this->_getWriteAdapter()->insert(
            $this->getOrderSentTable(),
            array(
                'order_id'  => $safeOrderId, // Order ID used in global collect
                'increment_id' => $incrementId,
                'created_at'   => now(),
                'test_mode' => Mage::getSingleton('globalcollect/config')->getField('test_mode')
            )
        );

        return $this;
    }

    /**
     * Set order is processed after redirect from global collect gateway
     *
     * @param string|array $incrementId
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function setOrderProcessed($incrementId, $isProcessed = true)
    {
        $this->_getWriteAdapter()->update(
            $this->getOrderSentTable(),
            array(
                'processed' => ($isProcessed ? self::PROCESSED_ORDER_STATUS : self::SENT_ORDER_STATUS)
            ),
            $this->_getWriteAdapter()->quoteInto('increment_id IN(?)', $incrementId)
        );

        return $this;
    }

    /**
     * Set order is processed after redirect from global collect gateway
     *
     * @param string|array $incrementId
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function setOrderPending($incrementId)
    {
        $this->_getWriteAdapter()->update(
            $this->getOrderSentTable(),
            array(
                'processed' => self::PENDING_ORDER_STATUS
            ),
            $this->_getWriteAdapter()->quoteInto('increment_id IN(?)', $incrementId)
        );

        return $this;
    }

    /**
     * Set order as checked after batch process creation
     *
     * @param string|array $incrementId
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function setOrderCheckedAt($incrementId)
    {
        $this->_getWriteAdapter()->update(
            $this->getOrderSentTable(),
            array(
                'checked_at' => now()
            ),
            $this->_getWriteAdapter()->quoteInto('increment_id IN(?)', $incrementId)
        );

        return $this;
    }

    /**
     * Truncate tables with payment products info
     *
     * @return Smile_Globalcollect_Model_Mysql4_Payment
     */
    public function clearPaymentProducts()
    {
        $this->_getWriteAdapter()->truncateTable($this->getTable('globalcollect/payment_product'));
        $this->_getWriteAdapter()->truncateTable($this->getTable('globalcollect/payment_scope'));
        $this->_getWriteAdapter()->truncateTable($this->getTable('globalcollect/payment_method'));

        return $this;
    }

}
