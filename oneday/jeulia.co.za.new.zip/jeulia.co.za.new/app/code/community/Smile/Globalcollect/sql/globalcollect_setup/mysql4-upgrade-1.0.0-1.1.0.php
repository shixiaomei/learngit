<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();
$installer->getConnection()->addColumn(
    $installer->getTable('sales/creditmemo'),
    'payment_reference',
    'VARCHAR(50) NULL DEFAULT NULL'
);

$installer->endSetup();
