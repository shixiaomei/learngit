<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global collect payment method for Hosted Merchant Link
 *
 */
class Smile_Globalcollect_Model_Method_Hosted extends Smile_Globalcollect_Model_Method_Abstract
{
    // Allowed all methods here, except of CC if PCI is yes //
    protected $_allowedMethods = array('neq' => Smile_Globalcollect_Model_Payment_Method::METHOD_CREDIT_CARD_ONLINE);
    // No join needed
    protected $_joinAllowedMethods = false;
    
    protected $_code  = 'globalcollect';

    protected $_formBlockType = 'globalcollect/form_hosted';
    protected $_infoBlockType = 'globalcollect/info_hosted';
    protected $_canSaveCc     = false;

    protected $_isHosted = true;
    
    /**
     * @inheritdoc
     */
    public function isAvailable($quote = null)
    {
        if ($this->isPCICompliant()) {
            $this->_joinAllowedMethods = true;
        }
        return parent::isAvailable($quote);
    }
    /**
     * To check billing country is allowed for the payment method
     *
     * @return bool
     */
    public function canUseForCountry($counrty)
    {
        $products = Mage::getSingleton('globalcollect/payment')->getPaymentProductCollection()
            ->join(array('methods_table'=> 'payment_method'), 'methods_table.payment_method_id = main_table.payment_method_id')
//            ->addFieldToFilter('methods_table.code', array('neq' => Smile_Globalcollect_Model_Payment_Method::METHOD_CREDIT_CARD_ONLINE))
            ->addFieldToFilter('`main_table`.payment_product_id', array('in'=> $this->_getConfig()->getAllowedPaymentProducts($this->getCode())))
            ->setScopeFilter($counrty, null);

        return parent::canUseForCountry($counrty) && $products->count();
    }

    /**
     *  Return Order Place Redirect URL
     *
     *  @return	  string Order Redirect URL
     */
    public function getOrderPlaceRedirectUrl()
    {
        if (Mage::getSingleton('checkout/session')->getGCOrderProcessed(true)) {
            return '';
        }
        $params = array (
            'order_id' => $this->getInfoInstance()->getQuote()->getReservedOrderId(),
            'iframe' => $this->getSelectedPaymentMethod()->isCreditCardOnline()
        );

        return Mage::getUrl('globalcollect/gateway/redirect', $params);
    }

    public function getRedirectInfo()
    {
        if (Mage::getSingleton('checkout/session')->getGCOrderProcessed(true)) {
            return '';
        }

        $payment = $this->getInfoInstance()->getAdditionalInformation('PAYMENT');

        return new Varien_Object(array(
            'form_action' => $payment['FORMACTION'],
            'form_method' => $payment['FORMMETHOD']
        ));
    }


    /**
     * Fill additional payment fields for api request
     *
     * @return array
     */
    protected function _getAdditionalPaymentFields()
    {
        $fields = array();
        $path = $this->getApi()->getPaymentPath();
        $is3dSecure = Mage::app()->getStore()->isAdmin() ? '0' : (int)$this->is3dSecureEnabled();
        if ($this->getSelectedPaymentMethod()->isCreditCardOnline()) {
            $fields[$path.'/CVVINDICATOR'] = $this->_getConfig()->getField('use_cvv');
            $fields[$path.'/AVSINDICATOR'] = $this->_getConfig()->getField('use_avs');
            $fields[$path.'/AUTHENTICATIONINDICATOR'] = $is3dSecure;
        }

        return $fields;
    }


    /**
     * Process api response after interting order
     *
     * @param array $response
     * @param Varien_Object $stateObject
     */
    protected function _responseInsertOrder($response, &$stateObject)
    {
        $statusId = $response['STATUSID'];

        if ($this->getSelectedPaymentMethod()->isCreditCardOnline() && !isset($response['FORMACTION'])) {
            // in case of token payment it can return status READY without redirect
            $this->_processCreditCard($response, $stateObject);

        } elseif (($statusId >= self::API_STATUS_PENDING_MERCHANT && $statusId <= self::API_STATUS_PENDING_CONSUMER)
            || ($statusId >= self::API_STATUS_READY && $statusId <= self::API_STATUS_PAID))
        {
            $stateObject->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
            $stateObject->setStatus($this->getStatusFromState($stateObject->getState()));
        } else {
            $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
        }
    }

    /**
     * Process api response on IOWP for credit cards in case when no redirect needed
     *
     * @param array $response
     * @param Varien_Object $stateObject
     */
    protected function _processCreditCard($response, $stateObject)
    {
        $statusId = $response['STATUSID'];
        $mode = $this->_getConfig()->getAuthenticationMode();

        if ($statusId == self::API_STATUS_CHALLENGED) {
            $this->_fraud($stateObject);
            Mage::getSingleton('checkout/session')->setGCOrderProcessed(true);
        } elseif ($statusId == self::API_STATUS_AUTHORIZED) {
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
            $message = Mage::helper('globalcollect')->__("Credit Card Authorized");
            $stateObject->setState($state);
            $stateObject->setStatus($this->getStatusFromState($state));
            $this->getOrder()->setCustomerNote($message);
            $this->_getPayment()->setOrderProcessed($this->getIncrementId());

            if ($mode == Smile_Globalcollect_Model_Source_Payment_Action::PAYMENT_ACTION_CAPTURE) {
                $this->getInfoInstance()->setDoNotUpdateStatus(true);
                $this->getInfoInstance()->capture(null);
            } else {
                $this->_createInvoice();
            }

            Mage::getSingleton('checkout/session')->setGCOrderProcessed(true);
        } elseif ($statusId == self::API_STATUS_READY) {
            $this->_getPayment()->setOrderProcessed($this->getIncrementId());
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
            $message = Mage::helper('globalcollect')->__("Credit Card Authorized");
            $stateObject->setState($state);
            $stateObject->setStatus($this->getStatusFromState($state));
            $this->getOrder()->setCustomerNote($message);
            $this->getInfoInstance()->setDoNotUpdateStatus(true);
            $this->getInfoInstance()->capture(null);

            Mage::getSingleton('checkout/session')->setGCOrderProcessed(true);
        } else {
            $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
        }
    }

    public function getReturnUrl($options = array())
    {
        $options = array(
            'iframe' => $this->getSelectedPaymentMethod()->isCreditCardOnline()
        );
        return parent::getReturnUrl($options);
    }

}
