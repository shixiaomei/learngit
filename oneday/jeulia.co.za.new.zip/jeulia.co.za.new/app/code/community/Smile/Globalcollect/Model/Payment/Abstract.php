<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment data abstract model
 *
 */
abstract class Smile_Globalcollect_Model_Payment_Abstract extends Mage_Core_Model_Abstract
{
    /**
     * Retrieve language code from different sources
     *
     * @param string|Mage_Core_Model_Locale|Zend_Locale|null $language
     * @return string;
     */
    protected function _getLanguage($language = null)
    {
        if ($language === null) {
            $language = Mage::app()->getLocale()->getLocale()->getLanguage();
        } elseif ($language instanceof Mage_Core_Model_Locale) {
            $language = $language->getLocale()->getLanguage();
        } elseif ($language instanceof Zend_Locale) {
            $language = $language->getLanguage();
        }

        $language = strtolower($language);
        return $language;
    }

    /**
     * Retrieve default label for this model
     *
     * @return string
     */
    public function getLabel()
    {
        return ($this->hasData('label') ? $this->_getData('label') : $this->getName());
    }


    /**
     * Import xml node to model
     *
     * @param Varien_Simplexml_Element $node
     * @return Smile_Globalcollect_Model_Payment_Abstract
     */
    abstract public function import(Varien_Simplexml_Element $node);

    /**
     * Get additional refund fields needed
     *
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Abstract
     */
    public function getAdditionalRefundInfo(&$newRefund, $payment)
    {
        return $this;
    }

    /**
     * Get refundable status for payment product
     *
     * @return bool|int
     */
    public function getRefundableStatus()
    {
        return false;
    }

    /**
     * Can refund
     *
     * @return bool
     */
    public function canRefund()
    {
        return (bool) $this->getRefundableStatus();
    }

    /**
     * Prepare refund fields
     *
     * @param $payment
     * @return array
     */
    public function prepareRefund($payment)
    {
        return array();
    }
}
