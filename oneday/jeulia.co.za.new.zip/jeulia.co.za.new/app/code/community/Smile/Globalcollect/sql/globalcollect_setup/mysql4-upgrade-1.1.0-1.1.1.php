<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();


$installer->getConnection()->dropForeignKey($installer->getTable('globalcollect/payment_product'),
    'GLOBALCOLLECT_PAYMENT_PRODUCT_METHOD'
);

$installer->getConnection()->addIndex($installer->getTable('globalcollect/payment_scope'),
    $installer->getIdxName(
        $installer->getTable('globalcollect/payment_scope'), array('payment_product_id', 'country_id')),
    array('payment_product_id', 'country_id')
);

/**
 * Create table 'globalcollect/token'
 */
$table = $installer->getConnection()
    ->newTable($installer->getTable('globalcollect/token'))
    ->addColumn('token_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity'  => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
    ), 'Token Id')
    ->addColumn('customer_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'unsigned'  => true,
        'nullable'  => false,
    ), 'Customer Id')
    ->addColumn('token', Varien_Db_Ddl_Table::TYPE_VARCHAR, 255, array(
        'nullable'  => false,
        'default'   => '',
    ), 'GC Token')
    ->addColumn('cc_number', Varien_Db_Ddl_Table::TYPE_VARCHAR, 255, array(
        'nullable'  => false,
        'default'   => '',
    ), 'CC Number')
    ->addColumn('expire_date', Varien_Db_Ddl_Table::TYPE_VARCHAR, 5, array(
        'nullable'  => false,
        'default'   => '',
    ), 'CC Expire date')
    ->addColumn('payment_product_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'nullable'  => true,
    ), 'CC Type')
    ->addColumn('effort_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'nullable'  => true,
        'default' => 1
    ), 'Effort ID')

    ->addIndex($installer->getIdxName('globalcollect/token', array('customer_id', 'cc_number')),
    array('customer_id', 'cc_number'));
$installer->getConnection()->dropTable($installer->getTable('globalcollect/token'));
$installer->getConnection()->createTable($table);

$installer->endSetup();
