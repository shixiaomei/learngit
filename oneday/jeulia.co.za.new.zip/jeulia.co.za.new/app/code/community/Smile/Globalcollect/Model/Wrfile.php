<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Object for manipulations with dayly report files
 *
 */
class Smile_Globalcollect_Model_Wrfile extends Varien_Object
{

    const WR_STATUS_PAID = 1;
    const WR_STATUS_CANCEL = 2;
    const WR_STATUS_REFUNDED = 3;
    const WR_STATUS_REFUND_REJECTED = 4;

    const REFERENCE_LENGTH = 19;

    /**
     *  Map WR file flag to order status
     */
    protected $_flags = array(
        '+IP' => array('position' => 50, 'status' => self::WR_STATUS_PAID),
        '+AP' => array('position' => 50, 'status' => self::WR_STATUS_PAID),
        'XAG' => array('position' => 50, 'status' => self::WR_STATUS_CANCEL),
        'XDI' => array('position' => 50, 'status' => self::WR_STATUS_CANCEL),
        '+ON' => array('position' => 15, 'status' => self::WR_STATUS_PAID),
        'XRN' => array('position' => 15, 'status' => self::WR_STATUS_CANCEL),
        'XRS' => array('position' => 15, 'status' => self::WR_STATUS_CANCEL),
        // refunds
        '-RF' => array('position' => 3, 'status' => self::WR_STATUS_REFUNDED, 'length' => 12),
        '-RC' => array('position' => 3, 'status' => self::WR_STATUS_REFUNDED, 'length' => 12),
        '-CR' => array('position' => 15, 'status' => self::WR_STATUS_REFUNDED),
        '+CR' => array('position' => 15, 'status' => self::WR_STATUS_REFUND_REJECTED, 'length' => 30),
    );

    /**
     * Fetch data from GC WR files,
     * gets yesterday and today files
     *
     * @return Smile_Globalcollect_Model_Wrfile
     */
    public function loadData()
    {
        $sftpConnection = new Varien_Io_Sftp();
        $date = Mage::app()->getLocale()->date();

        // for some reason Zend_Date returns wrong day of the year when using DDD format
        $date->add(1, Zend_Date::DAY);

        $merchantId = $this->_getConfig()->getField('merchant_id');
        $today = $merchantId . substr($date->toString(Zend_Date::YEAR_SHORT), 1) . $date->toString('DDD');
//        $yesterday = $merchantId . substr($date->toString(Zend_Date::YEAR_SHORT), 1) . $date->sub(1, Zend_Date::DAY)->toString('DDD');

        $lastCheck = $this->_getConfig()->getField('lastwr');
        if (!$lastCheck) {
            $lastCheck = $today;
        }

        $fileData = '';
        $testFileData = '';
        try {
            $sftpConnection->open(
                array(
                    'host'      => $this->_getConfig()->getField('sftp_host'),//'sft.globalcollect.com',
                    'username'  => $this->_getConfig()->getField('sftp_login'),
                    'password'  => $this->_getConfig()->getField('sftp_password'),
                    'timeout'   => '10'
                )
            );
            $sftpConnection->cd('out');

            for ($file=$lastCheck; $file <= $today; $file++) {
                // check live report first
                $data = $sftpConnection->read($file.".wr1");
                $this->_logFile($file, 1, $data);
                $fileData .= $data?$data:'';
                // wr1 file can be empty or missing, in this case we have to still check for wr2
                $i = 2;
                do {
                    $data = $sftpConnection->read($file.".wr{$i}");
                    $fileData .= $data?$data:'';
                    $this->_logFile($file, $i, $data);
                    $i++;
                } while ($data);

                // test report
                $data = $sftpConnection->read($file.'.wrt');
                $this->_logFile($file, 't', $data);
                $testFileData .= $data?$data:'';
            }

            $sftpConnection->close();
        } catch (Exception $e) {
            Mage::log(sprintf('Error downloading file %s: %s', $e->getMessage()), LOG_ERR, 'global_collect_wr.log');
            Mage::logException($e);
        }

        $this->setFileData(explode("\n", $fileData));
        $this->setTestFileData(explode("\n", $testFileData));

        if (strlen($fileData) || strlen($testFileData)) {
            $this->_getConfig()->save('lastwr', $today);
        }

        if ($this->_getConfig()->isDebug()) {
            Mage::log('LIVE:', 0, "global_collect.log");
            Mage::log($fileData, 0, "global_collect.log");
            Mage::log('TEST:', 0, "global_collect.log");
            Mage::log($testFileData, 0, "global_collect.log");
        }

        return $this;
    }

    protected function _logFile($file, $index, $data)
    {
        if ($data) {
            Mage::log(sprintf('Downloaded file %s.wr%s', $file, $index), LOG_DEBUG, 'global_collect_wr.log');
        } else {
            Mage::log(sprintf('Empty or non-existing file %s.wr%s', $file, $index), LOG_DEBUG, 'global_collect_wr.log');
        }
    }

    public function checkFlag($status_flag)
    {
        return isset($this->_flags[$status_flag])?$this->_flags[$status_flag]['status']:false;
    }

    /**
     * check if status flag corresponds to PAID order status
     *
     * @param $status_flag
     * @return bool
     */
    public function checkPaidFlag($status_flag)
    {
        return isset($this->_flags[$status_flag])?$this->_flags[$status_flag]['status']==self::WR_STATUS_PAID:false;
    }

    /**
     * check if status flag corresponds to Canceled order status
     *
     * @param $status_flag
     * @return bool
     */
    public function checkCancelFlag($status_flag)
    {
        return isset($this->_flags[$status_flag])?$this->_flags[$status_flag]['status']==self::WR_STATUS_CANCEL:false;
    }

    /**
     * check if status flag corresponds to Canceled order status
     *
     * @param $status_flag
     * @return bool
     */
    public function checkRefundedFlag($status_flag)
    {
        return isset($this->_flags[$status_flag])?$this->_flags[$status_flag]['status']==self::WR_STATUS_REFUNDED:false;
    }

    /**
     * Gets position of merchant reference in report file
     *
     * @return int
     */
    public function getReferencePosition($status_flag)
    {
        if (!isset($this->_flags[$status_flag])) {
            Mage::throwException("WR: Unknown Flag");
        }

        return $this->_flags[$status_flag]['position'];
    }

    public function getReferenceLength($status_flag = false)
    {
        if ($status_flag && isset($this->_flags[$status_flag])) {
            return isset($this->_flags[$status_flag]['length'])?$this->_flags[$status_flag]['length']:self::REFERENCE_LENGTH;
        }
        return self::REFERENCE_LENGTH;
    }

    /**
     * Retrieve Global Collect Config
     *
     * @return Smile_Globalcollect_Model_Config
     */
    protected function _getConfig()
    {
        return Mage::getSingleton('globalcollect/config');
    }

}
