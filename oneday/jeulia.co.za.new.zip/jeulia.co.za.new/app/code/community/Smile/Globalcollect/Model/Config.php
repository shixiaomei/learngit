<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global Collect config model
 *
 */
class Smile_Globalcollect_Model_Config extends Mage_Payment_Model_Config
{
    const CONFIG_PATH = 'payment/globalcollect/';


    /**
     * Global application currency
     *
     * @var Mage_Directory_Model_Currency
     */
    protected $_globalCurrency = null;

    /**
     * Api configuration model
     *
     * @var Smile_Globalcollect_Model_Config_Api
     */
    protected $_apiConfig = null;



    /**
     * Retrieve list of allowed payment product ids for specified method
     *
     * @param string $method
     * @param mixed $store
     * @return array
     */
    public function getAllowedPaymentProducts($method)
    {
        return unserialize(Mage::getStoreConfig(self::CONFIG_PATH.'enabled_products'));
    }

    public function getField($field) {
        return Mage::getStoreConfig(self::CONFIG_PATH.$field);
    }


    public function save($field, $value)
    {
        Mage::getConfig()->saveConfig(self::CONFIG_PATH.$field, $value);
        Mage::getConfig()->cleanCache();
    }

    /**
     * Retrieve authentication mode for payment method
     *
     * @param string $method
     * @param int|null $store
     * @return boolean
     */
    public function getAuthenticationMode()
    {
        return $this->getField('authentication_mode');
    }


    /**
     * @return bool
     */
    public function isDebug() {
        return Mage::getStoreConfigFlag(self::CONFIG_PATH.'debug');
    }

    /**
     * @return array
     */
    public function getAllowedCountries() {
        $countries = array();
        if (!Mage::getStoreConfigFlag(self::CONFIG_PATH.'allowspecific')) {
            foreach (Mage::getResourceModel('directory/country_collection')->loadData() as $country) {
                $countries[] = $country->getData('iso2_code');
            }
        } else {
            $countries = explode(',', $this->getField('specificcountry'));
        }
        return $countries;
    }

    public function is3dSecureEnabled()
    {
        return $this->getField('is_3dsecure');
    }

    /**
     * Get payment products IDs that supports online refunds
     *
     * @return array
     */
    public function getRefundablePaymentProducts()
    {
        return Mage::getStoreConfig(self::CONFIG_PATH.'refund_products')
            ?unserialize(Mage::getStoreConfig(self::CONFIG_PATH.'refund_products'))
            :array();
    }
}
