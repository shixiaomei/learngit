<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global collect payment method for Credit Cards and Merchant Link
 *
 */
class Smile_Globalcollect_Model_Method_Cc_Merchant extends Smile_Globalcollect_Model_Method_Abstract
{
    protected $_allowedMethods = array('credit-card-debit-card');
    
    protected $_code  = 'globalcollect_cc_merchant';
    protected $_isHosted = false;

    protected $_MOTOFormBlockType = 'globalcollect/adminhtml_form_moto';
    protected $_formBlockType = 'globalcollect/form_cc_merchant';
    protected $_infoBlockType = 'globalcollect/info_cc_merchant';
    protected $_canSaveCc     = false;


    /**
     * Retrieve block type for method form generation
     *
     * @return string
     */
    public function getFormBlockType()
    {
        return Mage::app()->getStore()->isAdmin()?$this->_MOTOFormBlockType:$this->_formBlockType;
    }

    /**
     * Assign data to info model instance
     *
     * @param   mixed $data
     * @return  Mage_Payment_Model_Info
     */
    public function assignData($data)
    {
        parent::assignData($data);

        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }
        $info = $this->getInfoInstance();
        $info->setCcType($data->getCcType())
            ->setCcOwner($data->getCcOwner())
            ->setCcLast4(substr($data->getCcNumber(), -4))
            ->setCcNumber($data->getCcNumber())
            ->setCcCid($data->getCcCid())
            ->setCcExpMonth($data->getCcExpMonth())
            ->setCcExpYear($data->getCcExpYear())
            ->setCcSsIssue($data->getCcSsIssue())
            ->setCcSsStartMonth($data->getCcSsStartMonth())
            ->setCcSsStartYear($data->getCcSsStartYear())
            ;

        $token = Mage::getModel('globalcollect/token');
        if ($data['token_id']) {
            $tokenData = array(
                'id' => $data['token_id'],
                'cc_exp_month' => $data->getCcExpMonth(),
                'cc_exp_year' => $data->getCcExpYear()
            );
            $token->validate($tokenData);
        }
        $this->getInfoInstance()->setAdditionalInformation('token_id', $token->getId());

        return $this;
    }

    /**
     * Fill additional payment fields for api request
     *
     * @return array
     */
    protected function _getAdditionalPaymentFields()
    {
        $strip = array(" ", "-");
        $fields = array();
        $path = $this->getApi()->getPaymentPath();

        if ($this->getSelectedToken()) {
            $fields[$path.'/EXPIRYDATE'] = trim($this->getCCExpiryDate());
        } else {
            $fields[$path.'/CVVINDICATOR'] = $this->_getConfig()->getField('use_cvv');
            $fields[$path.'/AVSINDICATOR'] = $this->_getConfig()->getField('use_avs');
            $fields[$path.'/EXPIRYDATE'] = trim($this->getCCExpiryDate());
            $fields[$path.'/CREDITCARDNUMBER'] = str_replace($strip, "", trim($this->getInfoInstance()->getCcNumber()));
        }

        $fields[$path.'/CVV'] = str_replace($strip, "", trim($this->getInfoInstance()->getCcCid()));

        $fields[$path.'/AUTHENTICATIONINDICATOR'] = 0; // no 3d secure for Merchant link

        return $fields;
    }

    /**
     * Process api response after inserting order
     *
     * @param array $response
     * @param Varien_Object $stateObject
     */
    protected function _responseInsertOrder($response, &$stateObject)
    {
        $statusId = $response['STATUSID'];

        $mode = $this->_getConfig()->getAuthenticationMode();

        if ($statusId == self::API_STATUS_CHALLENGED) {
            $this->_fraud($stateObject);
        } elseif ($statusId == self::API_STATUS_AUTHORIZED) {
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
            $message = Mage::helper('globalcollect')->__("Credit Card Authorized");
            $stateObject->setState($state);
            $stateObject->setStatus($this->getStatusFromState($state));
            $this->getOrder()->setCustomerNote($message);
            $this->_getPayment()->setOrderProcessed($this->getIncrementId());

            if ($mode == Smile_Globalcollect_Model_Source_Payment_Action::PAYMENT_ACTION_CAPTURE) {
                $this->getInfoInstance()->setDoNotUpdateStatus(true);
                $this->getInfoInstance()->capture(null);
            } else {
                $this->_createInvoice();
            }

            $this->_saveToken($response);
        } elseif ($statusId == self::API_STATUS_READY) {
            $this->_getPayment()->setOrderProcessed($this->getIncrementId());
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
            $message = Mage::helper('globalcollect')->__("Credit Card Authorized");
            $stateObject->setState($state);
            $stateObject->setStatus($this->getStatusFromState($state));
            $this->getOrder()->setCustomerNote($message);
            $this->getInfoInstance()->setDoNotUpdateStatus(true);
            $this->getInfoInstance()->capture(null);

            $this->_saveToken($response);
        } else {
            $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
        }

    }

    /**
     * Save token
     *
     * @param array $response
     * @return Smile_Globalcollect_Model_Method_Cc_Merchant
     */
    protected function _saveToken($response)
    {
        if ($this->getInfoInstance()->getAdditionalInformation('save_cc_data')) {
            Mage::getModel('globalcollect/token')
                    ->setCustomerId($this->getOrder()->getCustomerId())
                    ->setCcNumber('************'.$this->getInfoInstance()->getCcLast4())
                    ->setToken($response['ORDERID'])
                    ->setExpireDate(Mage::helper('globalcollect')->formatCcExpiryDate(
                            $this->getInfoInstance()->getCcExpMonth(),
                            $this->getInfoInstance()->getCcExpYear()
                    ))
                    ->setPaymentProductId($this->getSelectedPaymentProduct()->getId())
                    ->save();
        }

        return $this;
    }

    /**
     *  Return Order Place Redirect URL
     *
     *  @return	  string Order Redirect URL
     */
    public function getOrderPlaceRedirectUrl()
    {
        // return empty string because we don`t need redirect with merchant link
        return '';
    }

    /**
     * Check whether payment method can be used
     * @param Mage_Sales_Model_Quote $quote
     * @return bool
     */
    public function isAvailable($quote = null)
    {
        // Must be disabled for non PCI compliant websites //
        if (!$this->isPCICompliant()) {
            return false;
        }
        $result = Mage_Payment_Model_Method_Abstract::isAvailable($quote);

        // always enable CC_merchant method for MOTO payment in admin
        if (
            Mage::app()->getStore()->isAdmin() &&
            Mage::getStoreConfig('payment/globalcollect/active') &&
            $this->_getConfig()->getField('pci_compliant')
        ) {
            $result = true;
        }

        if ($result) {
            if ($quote !== null && !$this->hasInfoInstance()) {
                // We need to emulate info instance enviroment
                $this->setInfoInstance($quote->getPayment());
                $this->setInfoInstanceChanged(true);
            }

            $result = $this->getPaymentProducts()->count() > 0;

            if ($quote !== null && $this->getInfoInstanceChanged()) {
                $this->unsInfoInstance();
                $this->unsInfoInstanceChanged();
            }
        }

        return $result;
    }

    /**
     * Retrieve payment method title
     *
     * @return string
     */
    public function getTitle()
    {
        $motoText = Mage::app()->getStore()->isAdmin()
                ? Mage::helper('globalcollect')->__('MOTO payment ')
                :'';
        return $motoText.$this->getConfigData('title');
    }
}
