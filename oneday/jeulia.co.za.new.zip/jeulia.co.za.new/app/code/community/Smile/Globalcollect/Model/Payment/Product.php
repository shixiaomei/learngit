<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment product model
 *
 */
class Smile_Globalcollect_Model_Payment_Product extends Smile_Globalcollect_Model_Payment_Abstract
{
    const PRODUCT_GIROPAY = 816;

    const ORDER_TYPE_NORMAL = 1;
    const ORDER_TYPE_RECURRING = 4;

    const PRODUCT_BOLETO_BANCARIO_BRAZIL = 1503;
    const PRODUCT_NORDEA_EBATALING_SWEDEN = 805;
    const PRODUCT_IDEAL = 809;
    const PRODUCT_EPS_AUSTRIA_RAIFEISSEN = 820;
    const PRODUCT_EPS_AUSTRIA_VOLKSBANKEN_GRUPPE = 821;
    const PRODUCT_EPS_AUSTRIA_NO_HYPO = 822;
    const PRODUCT_EPS_AUSTRIA_VORALBERGER_HYPO = 823;
    const PRODUCT_EPS_AUSTRIA_BANKHAUS_SPANGLER = 824;
    const PRODUCT_EPS_AUSTRIA_HYPO_TIROL_BANK = 825;
    const PRODUCT_EPS_AUSTRIA_ERSTE_BANK = 826;
    const PRODUCT_EPS_AUSTRIA_BAWAG = 827;
    const PRODUCT_EPS_AUSTRIA_PSK = 828;
    const PRODUCT_EPS_AUSTRIA_EASY = 829;
    const PRODUCT_EPS_AUSTRIA_SPARDA_BANK = 831;

    const PRODUCT_BANK_TRANSFER = 11;

    const PRODUCT_SOFORTUBERWEISUNG = 836;
    const PRODUCT_PAYPAL = 840;
    const PRODUCT_BANK_MONEYBOOKERS = 843;
    const PRODUCT_BANK_CASHU = 845;

    const PRODUCT_WESTERN_UNION = 1501;
//    const PRODUCT_WESTERN_KOMBINI = 1501;

    const PRODUCT_CREDITCARD_VISA = 1;
    const PRODUCT_CREDITCARD_MASTERCARD = 3;
    const PRODUCT_CREDITCARD_VISA_ELECTRON = 122;
    const PRODUCT_CREDITCARD_MAESTRO = 117;

    const PRODUCT_DIRECTDEBIT = 701;

    const PRODUCT_BANK_REFUND = 1001;
    const PRODUCT_BANK_REFUND_AUSTRALIA = 1002;
    const PRODUCT_BANK_REFUND_AUSTRIA = 1003;
    const PRODUCT_BANK_REFUND_BELGIUM = 1004;
    const PRODUCT_BANK_REFUND_DENMARK = 1005;
    const PRODUCT_BANK_REFUND_FINLAND = 1006;
    const PRODUCT_BANK_REFUND_FRANCE = 1007;
    const PRODUCT_BANK_REFUND_GERMANY = 1008;
    const PRODUCT_BANK_REFUND_ITALY = 1009;
    const PRODUCT_BANK_REFUND_NETHERLANDS = 1010;
    const PRODUCT_BANK_REFUND_NORWAY = 1011;
    const PRODUCT_BANK_REFUND_SPAIN = 1012;
    const PRODUCT_BANK_REFUND_SWEDEN = 1013;
    const PRODUCT_BANK_REFUND_SWITZERLAND = 1014;
    const PRODUCT_BANK_REFUND_UNITED_KINGDOM = 1015;
    const PRODUCT_BANK_REFUND_JAPAN = 1016;
    const PRODUCT_BANK_REFUND_PORTUGAL = 1017;
    const PRODUCT_BANK_REFUND_CZECH = 1019;
    const PRODUCT_BANK_REFUND_ESTONIA = 1020;
    const PRODUCT_BANK_REFUND_HUNGARY = 1021;
    const PRODUCT_BANK_REFUND_IRELAND = 1022;
    const PRODUCT_BANK_REFUND_LATVIA = 1023;
    const PRODUCT_BANK_REFUND_POLAND = 1024;
    const PRODUCT_BANK_REFUND_SLOVENIA = 1025;
    const PRODUCT_BANK_REFUND_SOUTH_AFRICA = 1026;
    const PRODUCT_BANK_REFUND_BRAZIL = 1027;
    const PRODUCT_BANK_REFUND_CHINA = 1028;
    const PRODUCT_BANK_REFUND_LUXEMBOURG = 1029;
    const PRODUCT_BANK_REFUND_HONG_KONG = 1030;
    const PRODUCT_BANK_REFUND_TAIWAN = 1031;
    const PRODUCT_BANK_REFUND_NEW_ZEALAND = 10302;
    const PRODUCT_BANK_REFUND_SLOVAKIA = 1033;
    const PRODUCT_BANK_REFUND_SINGAPORE = 1034;
    const PRODUCT_BANK_REFUND_CANADA = 1035;
    const PRODUCT_BANK_REFUND_INDONESIA_IRD = 1036;
    const PRODUCT_BANK_REFUND_INDONESIA_USD = 1037;
    const PRODUCT_BANK_REFUND_MALAYSIA = 1038;
    const PRODUCT_BANK_REFUND_PHILIPPINES = 1039;
    const PRODUCT_BANK_REFUND_THAILAND = 1041;
    const PRODUCT_BANK_REFUND_ROMANIA_EUR = 1042;
    const PRODUCT_BANK_REFUND_ROMANIA = 1043;

    const PRODUCT_REFUND_WALLETS = 1040;


    protected $_refundCountryMap = array(
        'AU' => self::PRODUCT_BANK_REFUND_AUSTRALIA ,
        'AT' => self::PRODUCT_BANK_REFUND_AUSTRIA ,
        'BE' => self::PRODUCT_BANK_REFUND_BELGIUM ,
        'DK' => self::PRODUCT_BANK_REFUND_DENMARK ,
        'FI' => self::PRODUCT_BANK_REFUND_FINLAND ,
        'FR' => self::PRODUCT_BANK_REFUND_FRANCE ,
        'DE' => self::PRODUCT_BANK_REFUND_GERMANY ,
        'IT' => self::PRODUCT_BANK_REFUND_ITALY ,
        'NL' => self::PRODUCT_BANK_REFUND_NETHERLANDS ,
        'NO' => self::PRODUCT_BANK_REFUND_NORWAY ,
        'ES' => self::PRODUCT_BANK_REFUND_SPAIN ,
        'SE' => self::PRODUCT_BANK_REFUND_SWEDEN ,
        'CH' => self::PRODUCT_BANK_REFUND_SWITZERLAND ,
        'GB' => self::PRODUCT_BANK_REFUND_UNITED_KINGDOM ,
        'JP' => self::PRODUCT_BANK_REFUND_JAPAN ,
        'PT' => self::PRODUCT_BANK_REFUND_PORTUGAL ,
        'CZ' => self::PRODUCT_BANK_REFUND_CZECH ,
        'EE' => self::PRODUCT_BANK_REFUND_ESTONIA ,
        'HU' => self::PRODUCT_BANK_REFUND_HUNGARY ,
        'IE' => self::PRODUCT_BANK_REFUND_IRELAND ,
        'LV' => self::PRODUCT_BANK_REFUND_LATVIA ,
        'PL' => self::PRODUCT_BANK_REFUND_POLAND ,
        'SI' => self::PRODUCT_BANK_REFUND_SLOVENIA ,
        'ZA' => self::PRODUCT_BANK_REFUND_SOUTH_AFRICA ,
        'BR' => self::PRODUCT_BANK_REFUND_BRAZIL ,
        'CN' => self::PRODUCT_BANK_REFUND_CHINA ,
        'LU' => self::PRODUCT_BANK_REFUND_LUXEMBOURG ,
        'HK' => self::PRODUCT_BANK_REFUND_HONG_KONG ,
        'TW' => self::PRODUCT_BANK_REFUND_TAIWAN ,
        'NZ' => self::PRODUCT_BANK_REFUND_NEW_ZEALAND ,
        'SK' => self::PRODUCT_BANK_REFUND_SLOVAKIA ,
        'SG' => self::PRODUCT_BANK_REFUND_SINGAPORE ,
        'CA' => self::PRODUCT_BANK_REFUND_CANADA ,
//        'ID' => self::PRODUCT_BANK_REFUND_INDONESIA_IRD ,
        'ID' => self::PRODUCT_BANK_REFUND_INDONESIA_USD ,
        'MY' => self::PRODUCT_BANK_REFUND_MALAYSIA ,
        'PH' => self::PRODUCT_BANK_REFUND_PHILIPPINES ,
        'TH' => self::PRODUCT_BANK_REFUND_THAILAND ,
        'RO' => self::PRODUCT_BANK_REFUND_ROMANIA_EUR ,
//        'RO' => self::PRODUCT_BANK_REFUND_ROMANIA ,
    );

    protected $_fieldLength = array(
        'SWIFTCODE' => 11,
        'BANKACCOUNTNUMBER' => 10,
        'BRANCHCODE' => 10,
        'BANKCODE' => 15,
        'BANKCHECKDIGIT' => 2,
        'BANKNAME' => 255,
        'BANKADDRESS' => 255,
        'ACCOUNTNAME' => 35,
        'CITY' => 40,
        'STREET' => 50
    );





    protected function _construct()
    {
        $this->_init('globalcollect/payment_product');
    }

    /**
     * Set scope association to specified Merchant, Country, Currency
     *
     * @param string $countryId
     * @param string $currencyCode
     * @param int $orderType
     * @param float|null $minimumAmount
     * @param float|null $maximumAmount
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    public function saveScope($countryId, $currencyCode = null, $orderType = null, $minimumAmount = null, $maximumAmount = null)
    {
        $this->getResource()->saveScope($this->getId(), $countryId, $currencyCode, $orderType, $minimumAmount, $maximumAmount);
        return $this;
    }

    /**
     * Remove scope association to specified Merchant, Country, Currency
     *
     * @param string $countryId
     * @param string $currencyCode
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    public function unsetScope($countryId, $currencyCode = null)
    {
        $this->getResource()->unsetScope($this->getId(), $countryId, $currencyCode);
        return $this;
    }

    /**
     * Check existance of scope association to specified Merchant, Country, Currency
     *
     * @param $countryId
     * @param string $currencyCode
     * @return boolean
     */
    public function hasScope($countryId, $currencyCode = null)
    {
        return $this->getResource()->hasScope($this->getId(), $countryId, $currencyCode);
    }

    /**
     * Import xml node to model
     *
     * @param Varien_Simplexml_Element $node
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    public function import(Varien_Simplexml_Element $node)
    {
        if ($this->getCountryId() /*&& $this->getCurrencyCode() && $this->getMerchantId()*/) {
            $minimumAmount = (string) $node->MINAMOUNT;
            $maximumAmount = (string) $node->MAXAMOUNT;
            $minimumAmount = ($minimumAmount === '' ? null : ((int)$minimumAmount) / 100);
            $maximumAmount = ($maximumAmount === '' ? null : ((int)$maximumAmount) / 100);
            $this->saveScope(
                $this->getCountryId(),
                $this->getCurrencyCode(),
                (int) $node->ORDERTYPEINDICATOR,
                $minimumAmount,
                $maximumAmount
            );
        }
        return $this;
    }

    public function getName() {
        return $this->getCode();
    }

    /**
     * Check is this method confirms payment on status READY or on PAID
     *
     * @return boolean
     */
    public function isPaymentConfirmationNeeded() {
        return in_array($this->getId(), array(
            self::PRODUCT_SOFORTUBERWEISUNG,
        ));
    }


    /**
     * Check is payment product is Ideal payment
     *
     * @return boolean
     */
    public function isIdeal()
    {
        return $this->getId() == self::PRODUCT_IDEAL;
    }
    
    /**
     * Check is payment product is realtime bank transfer
     *
     * @return boolean
     */
    public function isRealTimeBankTransfer()
    {
        return in_array($this->getId(), array(
            self::PRODUCT_IDEAL,
            self::PRODUCT_SOFORTUBERWEISUNG,
            self::PRODUCT_GIROPAY
        ));
    }

    /**
     * Check is 3d secure authentication available for this payment method
     *
     * @return boolean
     */
    public function is3dSecureAvailable()
    {
        return in_array($this->getId(), array(
            self::PRODUCT_CREDITCARD_VISA,
            self::PRODUCT_CREDITCARD_MASTERCARD,
            self::PRODUCT_CREDITCARD_VISA_ELECTRON,
            self::PRODUCT_CREDITCARD_MAESTRO,
        ));
    }

    public function hasRequiredFilds() {
        return $this->getId() == self::PRODUCT_DIRECTDEBIT;
    }

    /**
     * Get refundable status for payment product
     *
     * @return bool|int
     */
    public function getRefundableStatus()
    {
        return Smile_Globalcollect_Model_Method_Abstract::API_STATUS_PAID;
    }

    /**
     * get additional refund fields needed
     *
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Abstract
     */
    public function getAdditionalRefundInfo(&$newRefund, $payment)
    {
        $refundMethod = '_refund' . $this->_mapRefundType();

        if (method_exists($this, $refundMethod)) {
            $this->$refundMethod($newRefund, $payment);
        }

        return $this;
    }

    /**
     * All info is already set, just do nothing
     *
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    protected function _refundAuto(&$newRefund, $payment)
    {
        return $this;
    }

    /**
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    protected function _refundWallet(&$newRefund, $payment)
    {
        $newRefund->setPaymentProductId(self::PRODUCT_REFUND_WALLETS);
        return $this;
    }


    /**
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Product
     */
    protected function _refundRealTimeBank(&$newRefund, $payment)
    {
        $status = $payment->getInfoInstance()->getAdditionalInformation('STATUS');
        if (!$status || !isset($status['CUSTOMERACCOUNT'])) {
            $payment->updateStatus();
            $status = $payment->getInfoInstance()->getAdditionalInformation('STATUS');
            $payment->getInfoInstance()->save();
        }
        if (!isset($status['CUSTOMERACCOUNT'])) {
            $payment->throwException('Can`t refund: Customer account Info missing');
        }
        $countryId = $payment->getOrder()->getBillingAddress()->getCountryId();
        $fields = $this->_mapRealTimeBankFields($countryId);

        $newRefund
            ->setPaymentProductId($this->_mapRealTimeBankPaymentMethod($payment->getOrder()->getBillingAddress()->getCountryId()))
            ->setData('BANKCOUNTRYCODE', $payment->getOrder()->getBillingAddress()->getCountryId());

        $creditMemoInfo = Mage::app()->getRequest()->getPost('creditmemo', array());
        foreach ($fields as $requestKey => $responseKey) {
            $value = '';
            if (isset($status['CUSTOMERACCOUNT'][$responseKey])) {
                $value =  $status['CUSTOMERACCOUNT'][$responseKey];
                //  Account number can contain a P, this must be stripped
                if ($responseKey == 'ACCOUNTNUMBER') {
                    $value = trim($value, 'Pp');
                }
            } elseif (isset($creditMemoInfo[$responseKey])) {
                $value = $creditMemoInfo[$responseKey];
                if (!$value && $requestKey == 'BANKADDRESS' && $countryId == 'NL')  {
                    // GlobalCollect asked to hardcode this
                    $value = 'AMSTERDAM';
                }
            } else {
                Mage::throwException(Mage::helper('globalcollect')->__('Can`t refund: Not enough Customer account Info. %s needed', $responseKey));
            }

            $newRefund->setData($requestKey, $this->cropField($requestKey, $value));
        }

        return $this;
    }

    /**
     * Get refund type
     *
     * @return bool|string
     */
    protected function _mapRefundType()
    {
        switch ($this->getId()) {
            case self::PRODUCT_SOFORTUBERWEISUNG :
            case self::PRODUCT_IDEAL :
            case self::PRODUCT_WESTERN_UNION :
                $refundMethod = 'RealTimeBank';
                break;
            case self::PRODUCT_BANK_CASHU:
            case self::PRODUCT_BANK_MONEYBOOKERS:
                $refundMethod = 'Wallet';
                break;
            case self::PRODUCT_PAYPAL :
                $refundMethod = 'Auto';
                break;
            default :
                $refundMethod = 'RealTimeBank';
        }

        return $refundMethod;
    }

    /**
     * Get required fields depending on country
     *
     * @param string $country
     * @return array
     */
    protected function _mapRealTimeBankFields($country)
    {
        $refundFieldMap = array();

        switch ($country) {
            case 'GB' :
            case 'AT' :
            case 'DE' :
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKCODE'] = 'BANKCODE';
                break;
            case 'BE' :
            case 'NL' :
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                break;
            case 'CH' :
            case 'PT' :
            case 'CZ' :
            case 'EE' :
            case 'HU' :
            case 'LV' :
            case 'SI' :
            case 'LU' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['IBAN'] = 'IBAN';
                $refundFieldMap['SWIFTCODE'] = 'BANKADDRESS';
                break;
            case 'IE' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['IBAN'] = 'IBAN';
                $refundFieldMap['SWIFTCODE'] = 'BANKADDRESS';
                break;
            case 'PL' :
            case 'DK' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['IBAN'] = 'IBAN';
                $refundFieldMap['BIC'] = 'BIC';
                break;
            case 'RO' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['IBAN'] = 'IBAN';
                $refundFieldMap['BIC'] = 'BIC';
                break;
            case 'FR' :
                $refundFieldMap['BANKCHECKDIGIT'] = 'BANKCHECKDIGIT';
                // no break
            case 'CA' :
                $refundFieldMap['BRANCHCODE'] = 'BRANCHCODE';
                // no break
            case 'AU' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['BANKCODE'] = 'BANKCODE';
                break;
            case 'FI' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BIC'] = 'BIC';
                break;
            case 'NO' :
                $refundFieldMap['BIC'] = 'BIC';
                $refundFieldMap['CITY'] = 'CITY';
                $refundFieldMap['ZIP'] = 'ZIP';
                // no break
            case 'IT' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['IBAN'] = 'IBAN';
                break;
            case 'ES' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['IBAN'] = 'IBAN';
                break;
            case 'ID' :
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                //no break
            case 'SE' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['SWIFTCODE'] = 'BANKADDRESS';
                break;
            case 'JP' :
                $refundFieldMap['BANKADDRESS'] = 'BANKCITY';
                $refundFieldMap['BRANCHCODE'] = 'BRANCHCODE';
                //no break
            case 'GB' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['BANKCODE'] = 'BANKCODE';
                break;
            case 'ZA' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['BRANCHCODE'] = 'BRANCHCODE';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                break;
            case 'CN' :
            case 'HK' :
                $refundFieldMap['ACCOUNTNAME'] = 'ACCOUNTHOLDERNAME';
                $refundFieldMap['BANKACCOUNTNUMBER'] = 'ACCOUNTNUMBER';
                $refundFieldMap['BANKNAME'] = 'BANKNAME';
                break;
        }

        return $refundFieldMap;

    }

    protected function _mapRealTimeBankPaymentMethod($country)
    {
        return isset($this->_refundCountryMap[$country])?$this->_refundCountryMap[$country]:self::PRODUCT_BANK_REFUND;
    }

    /**
     * Prepare refund fields
     *
     * @param $payment
     * @return array
     */
    public function prepareRefund($payment)
    {
        $mapMethod = '_map'.$this->_mapRefundType(). 'Fields';
        if (!method_exists($this, $mapMethod)) {
            return array();
        }

        $status = $payment->getInfoInstance()->getAdditionalInformation('STATUS');
        if (!$status || !isset($status['CUSTOMERACCOUNT'])) {
            $payment->updateStatus();
            $status = $payment->getInfoInstance()->getAdditionalInformation('STATUS');
            if (!isset($status['CUSTOMERACCOUNT'])) {
                $status['CUSTOMERACCOUNT'] = array();
                $payment->getInfoInstance()->setAdditionalInformation('STATUS', $status);
            }
            $payment->getInfoInstance()->save();
        }

        if ($payment->getInfoInstance()->getAdditionalInformation('STATUSID') < $this->getRefundableStatus()) {
            return false;
        }

        $fields = $this->$mapMethod($payment->getOrder()->getBillingAddress()->getCountryId());

        $refundFields = array();

        if (!$status['CUSTOMERACCOUNT']) {
            $refundFields = $fields;
        } else {
            foreach ($fields as $requestKey => $responseKey) {
                if (!isset($status['CUSTOMERACCOUNT'][$responseKey])) {
                    $refundFields[$requestKey] = $responseKey;
                }
            }
        }

        return $refundFields;
    }

    /**
     * Crop field value to max allowed length for it`s field
     *
     * @param string $key
     * @param string $value
     * @return string
     */
    public function cropField($key, $value)
    {
        $maxLength = isset($this->_fieldLength[$key])?$this->_fieldLength[$key]:0;
        if ($maxLength && strlen($value) > $maxLength) {
            $value = substr($value, 0, $maxLength);
        }

        return $value;
    }

}
