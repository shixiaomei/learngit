<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();

$installer->run("

DROP TABLE IF EXISTS `{$installer->getTable('globalcollect/payment_method')}`;
CREATE TABLE `{$installer->getTable('globalcollect/payment_method')}` (
  `payment_method_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY  (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `{$installer->getTable('globalcollect/payment_product')}`;
CREATE TABLE `{$installer->getTable('globalcollect/payment_product')}` (
  `payment_product_id` smallint(5) unsigned NOT NULL,
  `code` varchar(64) NOT NULL DEFAULT '',
  `payment_method_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`payment_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `{$installer->getTable('globalcollect/payment_scope')}`;
CREATE TABLE `{$installer->getTable('globalcollect/payment_scope')}` (
  `payment_product_id` smallint(5) unsigned NOT NULL,
  `country_id` char(3) NOT NULL DEFAULT '',
  `language` char(2) NOT NULL,
  `currency_code` char(3) NULL DEFAULT NULL,
   `minimum_amount` DECIMAL(12,4) UNSIGNED NULL DEFAULT NULL,
   `maximum_amount` DECIMAL(12,4) UNSIGNED NULL DEFAULT NULL,
   `order_type` TINYINT(3) UNSIGNED NULL DEFAULT '0',
  `collected_at` datetime DEFAULT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `{$installer->getTable('globalcollect/order_sent')}`;
CREATE TABLE `{$installer->getTable('globalcollect/order_sent')}` (
    `order_id` varchar(50) NOT NULL,
    `increment_id` varchar(50) NOT NULL,
    `created_at` datetime NOT NULL,
    `checked_at` datetime DEFAULT NULL,
    `processed` tinyint(2) NOT NULL DEFAULT '0',
    PRIMARY KEY(`order_id`),
    KEY `increment_id` (`increment_id`),
    KEY `created_at` (`created_at`),
    KEY `checked_at` (`checked_at`),
    KEY `processed` (`processed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* This table should be not transactional to support cheking sent orders */

");


$installer->getConnection()->addConstraint(
    'GLOBALCOLLECT_PAYMENT_PRODUCT_METHOD',
    $installer->getTable('globalcollect/payment_product'),
    'payment_method_id',
    $installer->getTable('globalcollect/payment_method'),
    'payment_method_id'
);

$installer->endSetup();
