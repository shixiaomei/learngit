<?php


class Smile_Globalcollect_Block_Iframe extends Mage_Core_Block_Template
{
	private $_formAction = '';

	public function setFormAction($formAction)
	{
		$this->_formAction = $formAction;

		return $this;
	}

	public function getFormAction()
	{

		return $this->_formAction;
	}

	public function getPaymentnProducts()
	{
		return array(
			'1'		=> $this->__('Visa'),
			'3'		=> $this->__('MasterCard'),
			'114'	=> $this->__('Visa Debit'),
			'119'	=> $this->__('Mastercard Debit'),
			'122'	=> $this->__('Visa Electron'),
			//'128'	=> $this->__('Discover'),
			'132'	=> $this->__('Diners Club'),
		);
	}
}
