<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material 
 * are the property of their respective owners This software is not intended 
 * to be a complete solution of all applicable rules, policies and procedures. 
 * The matters referenced are subject to change from time to time, and 
 * individual circumstances may vary. Global Collect Services B.V. shall not 
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality 
 * of the software but makes no warranties or representations about the accuracy 
 * or completeness of it. Neither Global Collect Services B.V. nor any of its 
 * affiliates shall be liable for any costs, losses and/or damages arising out 
 * of access to or use of this software. Because of the complexity of the process 
 * and the right of Banks to alter conditions, this software can only serve 
 * as a quick-start in development is subject to further modifications.
 * 
 * The Magento extension was developed as a generic solution. 
 * In the event that the cartridge is modified by a user in any way, 
 * Global Collect Services B.V. shall not be responsible for any damages that 
 * are caused by the modified extension. Global Collect Services B.V. makes 
 * no warranties or representations about the use or operation of the extension. 
 * Neither Global Collect Services B.V. nor any of its affiliates shall be 
 * liable for any costs, losses and/or damages arising out of access to 
 * or use of the extension.
 * 
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to 
 * global.partnerships@globalcollect.com
 *  
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

class Smile_Globalcollect_GatewayController extends Mage_Core_Controller_Front_Action {

    protected function _initOrder()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        if ($orderId) {
            /**
             * @var $order Mage_Sales_Model_Order
             */
            $order = Mage::getModel('sales/order')->load($orderId);
            if (!$order->getId()) {
                $order = Mage::getModel('sales/order')->loadByIncrementId($orderId);
            }
            if ($order->getId()) {
                Mage::register('globalcollect_current_order', $order);
                return $order;
            }
        }

        return false;
    }
    
    public function redirectAction() {
        $session = Mage::getSingleton('checkout/session');
        $this->_initOrder();
        
        if ($session->getQuote()->getHasError()) {
            $this->_redirect('checkout/cart');
        } else {
            $this->loadLayout();
            if ($this->getRequest()->getParam('iframe')) {
                 $this->getLayout()->getBlock('global_collect_redirect')
                                ->setTemplate("globalcollect/form/iframe.phtml");
            }
           
            $this->renderLayout();
        }
    }
    
    public function returnAction() {
        $order = $this->_initOrder();
        $session = Mage::getSingleton('checkout/session');
        if ($order) {
            try {
                $order->getPayment()->getMethodInstance()->processReturned();
                
                $this->_redirect('checkout/onepage/success', array('_secure'=>true));
            } catch (Smile_Globalcollect_Exception $e) {
                // if exception occurs than payment was not successful

                // set customer quote, so one could reorder it
                $session->replaceQuote(
                        Mage::getModel('sales/quote')
                        ->load($order->getQuoteId())
                        ->setIsActive(true)
                        ->save()
                );

                $session->addError($e->getMessage());
                $this->_redirect('checkout/cart');
            }
        } else {
            $session->addError($this->__("Unknown payment error"));
            $this->_redirect('checkout/cart');
        }
        
    }
    
    /**
     * Set redirect into response
     *
     * @param   string $path
     * @param   array $arguments
     * @return  Mage_Core_Controller_Varien_Action
     */
    protected function _redirect($path, $arguments = array())
    {
        if ($this->getRequest()->getParam('iframe')) {
            /** @var $session Mage_Core_Model_Session */
            $session = Mage::getSingleton('core/session', array('name' => $this->_sessionNamespace));
            if ($session->getCookieShouldBeReceived() && Mage::app()->getUseSessionInUrl()
                && $this->_sessionNamespace != Mage_Adminhtml_Controller_Action::SESSION_NAMESPACE
            ) {
                $arguments += array('_query' => array(
                    $session->getSessionIdQueryParam() => $session->getSessionId()
                ));
            }
            
            $block = $this->getLayout()->createBlock('core/template')
                        ->setTemplate('globalcollect/iframe_return.phtml')
                        ->setRedirectUrl(Mage::getUrl($path, $arguments));
            
            $this->getResponse()->setBody($block->toHtml());
            return $this;
        }
        return parent::_redirect($path, $arguments);
    }

}
