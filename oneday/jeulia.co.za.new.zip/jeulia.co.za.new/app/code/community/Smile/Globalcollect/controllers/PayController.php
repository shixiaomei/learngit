<?php

class Smile_Globalcollect_PayController extends Mage_Core_Controller_Front_Action {

    const API_RESULT_OK = 'OK';
    const API_RESULT_NOK = 'NOK';

    private $gatewayUrl;

    public function preDispatch() {
        $this->gatewayUrl = Mage::getStoreConfig('payment/globalcollect/gateway_url');

        parent::preDispatch();
    }

    public function insertwithpaymentAction() {
        $session = Mage::getSingleton('checkout/session');
        $order = $this->_initOrder();

        if (!$order) {
            $this->_responseJson(
                    array('errorCode' => 1, 'errorMsg' => $this->__('Order does not exits.'))
            );

            return;
        }

        $paymentProductId = $this->getRequest()->getParam('productId');

        $request = $this->_initRequest();
        $request = $request->REQUEST;

        $language = Mage::app()->getLocale()->getLocale()->getLanguage();
        $address = $order->getBillingAddress();

        $gift_message_id = $order->getGiftMessageId();
        $gift_message_id = (int) $gift_message_id + 1;

        $remoteIP = Mage::app()->getRequest()->getServer('HTTP_X_FORWARDED_FOR');

        if (!$remoteIP) {
            $remoteIP = Mage::helper('core/http')->getRemoteAddr();
        }

        $request->setNode('PARAMS/ORDER/ORDERID', $order->getId());
        $request->setNode('PARAMS/ORDER/AMOUNT', (int) round($order->getBaseGrandTotal() * 100));
        $request->setNode('PARAMS/ORDER/CURRENCYCODE', $order->getOrderCurrencyCode());
        $request->setNode('PARAMS/ORDER/LANGUAGECODE', $language);
        $request->setNode('PARAMS/ORDER/LANGUAGE', $language);
        $request->setNode('PARAMS/ORDER/COUNTRYCODE', strtoupper($order->getBillingAddress()->getCountry()));
        $request->setNode('PARAMS/ORDER/MERCHANTREFERENCE', $order->getIncrementId() . '-' . $gift_message_id);
        $request->setNode('PARAMS/ORDER/IPADDRESSCUSTOMER', $remoteIP);
        $request->setNode('PARAMS/ORDER/FIRSTNAME', substr($address->getFirstname(), 0, 15));
        $request->setNode('PARAMS/ORDER/SURNAME', substr($address->getLastname(), 0, 15));
        $request->setNode('PARAMS/ORDER/STREET', substr($address->getStreetFull(), 0, 50));
        $request->setNode('PARAMS/ORDER/CITY', substr($address->getCity(), 0, 40));
        $request->setNode('PARAMS/ORDER/ZIP', substr(preg_replace("/[^ a-zA-Z0-9]+/", "", $address->getPostcode()), 0, 10));
        $request->setNode('PARAMS/ORDER/COMPANYNAME', substr(preg_replace("/[^ a-zA-Z0-9]+/", "", $address->getPostcode()), 0, 10));
        $request->setNode('PARAMS/ORDER/EMAIL', $order->getCustomerEmail());
        $request->setNode('PARAMS/ORDER/SHIPPINGFIRSTNAME', substr($order->getShippingAddress()->getFirstname(), 0, 15));
        $request->setNode('PARAMS/ORDER/SHIPPINGSURNAME', substr($order->getShippingAddress()->getLastname(), 0, 15));
        $request->setNode('PARAMS/ORDER/SHIPPINGSTREET', substr($order->getShippingAddress()->getStreetFull(), 0, 50));
        $request->setNode('PARAMS/ORDER/SHIPPINGZIP', substr(preg_replace("/[^ a-zA-Z0-9]+/", "", $order->getShippingAddress()->getPostcode()), 0, 10));
        $request->setNode('PARAMS/ORDER/SHIPPINGCITY', substr($order->getShippingAddress()->getCity(), 0, 40));
        $request->setNode('PARAMS/ORDER/SHIPPINGCOUNTRYCODE', $order->getShippingAddress()->getCountryId());

        $request->setNode('PARAMS/PAYMENT/PAYMENTPRODUCTID', $paymentProductId);
        $request->setNode('PARAMS/PAYMENT/AMOUNT', (int) round($order->getGrandTotal() * 100));
        $request->setNode('PARAMS/PAYMENT/LANGUAGECODE', $language);
        $request->setNode('PARAMS/PAYMENT/COUNTRYCODE', $address->getCountry());
        $request->setNode('PARAMS/PAYMENT/RETURNURL', Mage::getUrl('globalcollect/pay/return'));
        $request->setNode('PARAMS/PAYMENT/CURRENCYCODE', $order->getOrderCurrencyCode());
        $request->setNode('PARAMS/PAYMENT/HOSTEDINDICATOR', 1);

        $xmlResponse = $this->call($request);

        $order->setGiftMessageId($gift_message_id)->save();

        if (!$this->isResponseSuccessfull($xmlResponse)) {
            $this->_responseJson(
                    array('errorCode' => 1, 'errorMsg' => (string) $xmlResponse->descend('REQUEST/RESPONSE/ERROR/MESSAGE'))
            );

            return;
        }

        $formAction = (string) $xmlResponse->descend('REQUEST/RESPONSE/ROW/FORMACTION');

        $this->_responseJson(
                array('errorCode' => 0, 'redirect' => $formAction)
        );
    }

    public function returnAction() {
        if (!Mage::getStoreConfig('payment/globalcollect/active')) {
            return false;
        }

        $externalreference = $this->getRequest()->getParam('EXTERNALREFERENCE');

        if ($externalreference) {


            $ext_increment_id = explode('-', $externalreference);
            $increment_id = isset($ext_increment_id[0]) ? trim($ext_increment_id[0]) : false;

            if ($increment_id) {

                $order = Mage::getModel('sales/order')->load($increment_id, 'increment_id');
                if ($order->getId()) {
                    if ($this->isOrderProcessing($this->getOrderStatus($order->getId()))) {
                        $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING)
                                ->setStatus(Mage_Sales_Model_Order::STATE_PROCESSING);
                        $order->save();
                        Jeulia_Core_Model_Email_Sales_Order::send_confirm_order($order); 
                    } elseif ($this->isOrderHolded($this->getOrderStatus($order->getId()))) {
                        $order->setState(Mage_Sales_Model_Order::STATE_HOLDED)
                                ->setStatus(Mage_Sales_Model_Order::STATE_HOLDED);
                        $order->save();
                    } else {
                        die('Sorry, your payment failed. Please try another payment method');
                    }

                    $order->getPayment()->setMethod('globalcollect_cc_merchant')->save();

                    Jeulia_Erp_Model_Order::status($order->getIncrementId(), $order->getStatus(), 'globalcollect_cc_merchant');

                    $_session = Mage::getSingleton('checkout/session');

                    $_session->setLastSuccessQuoteId($order->getQuoteId());
                    $_session->setLastQuoteId($order->getQuoteId());
                    $_session->setLastOrderId($order->getId())
                            ->setLastRealOrderId($order->getIncrementId());

                    //$order->sendNewOrderEmail();

                    echo $this->_getBlock('globalcollect/success.phtml')->toHtml();
                }
            }
        }
    }

    protected function _responseJson($data) {
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($data));
    }

    protected function _getBlock($template) {
        $this->loadLayout();
        $_block = $this->getLayout()->createBlock('globalcollect/iframe')->setTemplate($template);

        return $_block;
    }

    protected function _initOrder() {
        if (!Mage::getStoreConfig('payment/globalcollect/active')) {
            return false;
        }

        $orderId = $this->getRequest()->getParam('order_id');
        if ($orderId) {
            /**
             * @var $order Mage_Sales_Model_Order
             */
            $order = Mage::getModel('sales/order')->load($orderId);
            if (!$order->getId()) {
                $order = Mage::getModel('sales/order')->loadByIncrementId($orderId);
            }
            if ($order->getId()) {
                Mage::register('globalcollect_current_order', $order);
                return $order;
            }
        }

        return false;
    }

    /**
     * Initialize request for account
     *
     *
     * @param string|int $account account name or merchant id
     * @param string $version
     * @return Varien_Simplexml_Element
     */
    protected function _initRequest($action = 'INSERT_ORDERWITHPAYMENT') {
        $request = new Varien_Simplexml_Element('<XML><REQUEST></REQUEST></XML>');

        $_node = $request->REQUEST;

        $_node->setNode('META/MERCHANTID', Mage::getStoreConfig('payment/globalcollect/merchant_id'));
        $_node->setNode('META/IPADDRESS', Mage::helper('core/http')->getServerAddr());
        $_node->setNode('META/VERSION', '1.0');
        $_node->setNode('ACTION', $action);

        return $request;
    }

    /**
     * Post request api.
     */
    protected function call($request) {
        $http = new Varien_Http_Adapter_Curl();
        $http->setOptions(array(CURLOPT_SSL_VERIFYHOST => false, CURLOPT_SSL_VERIFYPEER => false));
        $http->write(
                Zend_Http_Client::POST, $this->gatewayUrl, '1.1', array(), $request->asNiceXml()
        );

        // read the remote file
        $data = $http->read();

        if (strpos($data, '<XML>') === false || strpos($data, '</XML>') === false) {
            return false;
        }

        $data = preg_split('/^\r?$/m', $data, 2);


        //print_r($data);
        $response = trim($data[1]);

        $xmlResponse = simplexml_load_string($response, 'Varien_Simplexml_Element');

        $log_file = sprintf("global_collect-%s.log", date('Y-m-d'));
        Mage::log($request->asNiceXml(), 0, $log_file);
        Mage::log(var_export($xmlResponse->descend('REQUEST/RESPONSE'), true), 0, $log_file);

        return $xmlResponse;
    }

    /**
     * Check response is successfull
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return boolean
     */
    protected function isResponseSuccessfull($response) {
        if (!$response instanceof Varien_Simplexml_Element) {
            return false;
        }

        $result = (string) $response->descend('REQUEST/RESPONSE/RESULT');

        if ($result === self::API_RESULT_OK) {
            return true;
        }

        return false;
    }

    /**
     * Get order statusid.
     */
    protected function getOrderStatus($orderId) {
        $request = $this->_initRequest('GET_ORDERSTATUS');
        $request = $request->REQUEST;

        $request->setNode('PARAMS/ORDER/ORDERID', $orderId);

        $xmlResponse = $this->call($request);

        if (!$this->isResponseSuccessfull($xmlResponse)) {
            return -1;
        }

        return (string) $xmlResponse->descend('REQUEST/RESPONSE/ROW/STATUSID');
    }

    /**
     *
     */
    protected function isOrderProcessing($statusId) {
        /**
         *   const API_STATUS_READY = 800;
         *   const API_STATUS_READY_TO_SEND = 850;
         *   const API_STATUS_SENT = 900;
         *   const API_STATUS_REFUND_PROCESSED = 900;
         *   const API_STATUS_INVOICE_SENT = 950;
         *   const API_STATUS_SETTELMENT_PROCESSING = 975;
         *   const API_STATUS_PAID = 1000;
         *   const API_STATUS_ACCOUNT_DEBITED = 1010;
         *   const API_STATUS_PAYMENT_CORRECTED = 1020;
         *   const API_STATUS_COLLECTED = 1050;
         */
        $status = array(
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_READY,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_READY_TO_SEND,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_SENT,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_REFUND_PROCESSED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_INVOICE_SENT,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_SETTELMENT_PROCESSING,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_PAID,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_ACCOUNT_DEBITED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_PAYMENT_CORRECTED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_COLLECTED,
        );
        if (!in_array($statusId, $status)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    //holded order status
    protected function isOrderHolded($statusId) {
        /**
         * base:Smile_Globalcollect_Model_Method_Abstract
         * const API_STATUS_REVISED = 400;
         * const API_STATUS_CHALLENGED = 525;
         * const API_STATUS_REFERRED = 550;
         * const API_STATUS_AUTHORIZED = 600;
         */
        $status = array(
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_REVISED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_CHALLENGED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_REFERRED,
            Smile_Globalcollect_Model_Method_Hosted::API_STATUS_AUTHORIZED
        );
        if (!in_array($statusId, $status)) {
            $result = FALSE;
        } else {
            $result = true;
        }
        return $result;
    }

}
