<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global Collect observer
 *
 */
class Smile_Globalcollect_Model_Observer
{
     /**
     * Payment flags and data manipulation model
     *
     * @var Smile_Globalcollect_Model_Payment
     */
    protected $_payment = null;

    /**
     * Order
     *
     * @var  Mage_Sales_Model_Order
     */
    protected $_order = null;

    /**
     * Retrieve payment flags and manipulation model
     *
     * @return Smile_Globalcollect_Model_Payment
     */
    protected function _getPayment()
    {
        if ($this->_payment=== null) {
            $this->_payment = Mage::getSingleton('globalcollect/payment');
        }

        return $this->_payment;
    }

    /**
     * On core_block_abstract_prepare_layout_after
     *
     * @param $observer
     */
    public function adminCanRefund($observer)
    {
        $block = $observer->getBlock();
        // having child 'submit_button' means that canRefund() function had returned true
        if ($block instanceof Mage_Adminhtml_Block_Sales_Order_Creditmemo_Create_Items
            && $block->getChild('submit_button')
        ) {
			$methodInstance = $block->getCreditMemo()->getOrder()->getPayment()->getMethodInstance();
			if (is_subclass_of($methodInstance, 'Smile_Globalcollect_Model_Method_Abstract')) {
				$fields = $methodInstance->prepareRefund();
				if (is_array($fields)) {
					// if globalcollect_refund_fields already initialized - fill it with data
					// otherwise store data for later pickup by block
					if ($refundBlock = $block->getLayout()->getBlock('globalcollect_refund_fields')) {
						$refundBlock->setFields($fields);
					} else {
						Mage::register('refund_fields', $fields);
					}
				} else {
					$block->unsetChild('submit_button');
				}
			} else {
				$block->unsetChild('submit_button');
			}
        }
    }


    /**
     * Processes order batch by cron,
     * Gets not processed orders, and resolves GC order status,
     * Than depends on status confirms capture, authorization or declines order at all
     *
     */
    public function processOrderBatch()
    {
        $orderIds = $this->_getPayment()->getOrderIdsForBatch();

        $order = Mage::getModel('sales/order');
         if (Mage::getSingleton('globalcollect/config')->isDebug()) {
            Mage::log('batch processing:', 0, "global_collect.log");
            Mage::log($orderIds, 0, "global_collect.log");
        }

        foreach ($orderIds as $orderId) {
            try {
                $order->reset();
                $order->loadByIncrementId($orderId['increment_id']);
                if ($order->getPayment() &&
                    $order->getPayment()->getMethodInstance() instanceof Smile_Globalcollect_Model_Method_Abstract)
                {
                    // switch store from admin to order's store //
                    if ($order->getStoreId() != Mage::app()->getStore()->getId()) {
                        Mage::app()->setCurrentStore(Mage::app()->getStore($order->getStoreId()));
                    }
                    $order->getPayment()->getMethodInstance()->processBatch($orderId['expired']);
                    $order->save();
                    $this->_getPayment()->setOrderCheckedAt($orderId);
                } else {
                    // If order has different method selected we need
                    // to set it as processed for avoiding of further processing by globalcollect
                    $this->_getPayment()->setOrderProcessed($orderId, true);
                }
            } catch (Exception $e) {
                Mage::logException($e);
            }
        }
        // Restore back admin store needed //
        if (!Mage::app()->getStore()->isAdmin()) {
            Mage::app()->setCurrentStore(Mage::app()->getStore(0));
        }
    }
    
    /**
     * Processes order batch by cron, Cancels expired pending orders
     */
    public function processOrderCleanup()
    {
        $orderIds = $this->_getPayment()->getOrdersForCleanup();
        $order = Mage::getModel('sales/order');
        if (Mage::getSingleton('globalcollect/config')->isDebug()) {
            Mage::log('order clean:', 0, "global_collect.log");
            Mage::log($orderIds, 0, "global_collect.log");
        }
        foreach ($orderIds as $orderId) {
            try {
                $order->reset();
                $order->loadByIncrementId($orderId['increment_id']);
                
                // switch store from admin to order's store //
                if ($order->getStoreId() != Mage::app()->getStore()->getId()) {
                    Mage::app()->setCurrentStore(Mage::app()->getStore($order->getStoreId()));
                }
                
                if ($order->getPayment() &&
                    $order->getPayment()->getMethodInstance() instanceof Smile_Globalcollect_Model_Method_Abstract)
                {
                    $order->getPayment()->getMethodInstance()->processCleanup($orderId['created_at']);
                    $order->save();
                } else {
                    // If order has different method selected we need
                    // to set it as processed for avoiding of further processing by globalcollect
                    $this->_getPayment()->setOrderProcessed($orderId, true);
                }
            } catch (Exception $e) {
                Mage::logException($e);
            }
        }
        // Restore back admin store needed //
        if (!Mage::app()->getStore()->isAdmin()) {
            Mage::app()->setCurrentStore(Mage::app()->getStore(0));
        }
    }    

    /**
     * Processes order batch by cron,
     * Gets daily report from GloballCollect and resolves not processed orders
     * Than depends on status confirms capture, authorization or declines order at all
     *
     */
    public function processOrderBatchWR()
    {
        $orderIds = $this->_getPayment()->getOrderIdsForWR();
        $order = Mage::getModel('sales/order');

        $reportData = Mage::getModel('globalcollect/wrfile')->loadData();

        if (Mage::getSingleton('globalcollect/config')->isDebug()) {
            Mage::log('batch WR processing:', 0, "global_collect.log");
            Mage::log($orderIds, 0, "global_collect.log");
        }
        foreach ($orderIds as $orderId) {
            try {
                $order->reset();
                $order->loadByIncrementId($orderId['increment_id']);
                if ($order->getPayment() &&
                    $order->getPayment()->getMethodInstance() instanceof Smile_Globalcollect_Model_Method_Abstract)
                {
                    $order->getPayment()->getMethodInstance()->processWR(
                        $reportData, $orderId['expired'], $orderId['test_mode']
                    );
                    $order->save();
                    $this->_getPayment()->setOrderCheckedAt($orderId);
                } else {
                    // If order has diffrent method selected we need
                    // to set it as processed for avoiding of futher processing by globalcollect
                    $this->_getPayment()->setOrderProcessed($orderId, true);
                }
            } catch (Exception $e) {
                Mage::logException($e);
            }
        }
    }

}
