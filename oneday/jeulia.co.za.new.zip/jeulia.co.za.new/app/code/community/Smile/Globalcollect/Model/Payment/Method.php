<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Payment method model
 *
 */
class Smile_Globalcollect_Model_Payment_Method extends Smile_Globalcollect_Model_Payment_Abstract
{

    const METHOD_CREDIT_CARD_ONLINE = 'credit-card-debit-card';
    const METHOD_REAL_TIME_BANK_TRANSFER = 'online-banking';
    const METHOD_CHEQUE = 'cheque-money-order-postal-order';
    const METHOD_BANK_TRANSFER = 'bank-transfer';
    const METHOD_DIRECT_DEBIT = 'direct-debit';
    const METHOD_REFUND = 'bank-refund';


    protected function _construct()
    {
        $this->_init('globalcollect/payment_method');
    }

    /**
     * Import xml node to model
     *
     * @param Varien_Simplexml_Element $node
     * @return Smile_Globalcollect_Model_Payment_Method
     */
    public function import(Varien_Simplexml_Element $node)
    {

        return $this;
    }

    /**
     * Check is payment method is credit card online
     *
     * @return boolean
     */
    public function isCreditCardOnline()
    {
        return $this->getCode() == self::METHOD_CREDIT_CARD_ONLINE;
    }

    /**
     * Check is payment method realtime bank transfer
     *
     * @deprecated method code comes from GC and gives wrong grouping
     * @return boolean
     */
    public function isRealTimeBankTransfer()
    {
        return $this->getCode() == self::METHOD_REAL_TIME_BANK_TRANSFER;
    }

    /**
     * Check is this method confirms payment on status READY or on PAID
     *
     * @return boolean
     */
    public function isPaymentConfirmationNeeded() {
        return in_array($this->getCode(), array(
                        self::METHOD_CHEQUE,
                        self::METHOD_BANK_TRANSFER,
                        self::METHOD_DIRECT_DEBIT
                    )
                );
    }

    /**
     * Loading tag by name
     *
     * @param Mage_Tag_Model_Tag $model
     * @param string $name
     * @return array|false
     */
    public function loadByCode($code)
    {
        $this->_getResource()->loadByCode($this, $code);
        return $this;
    }

    /**
     * Check is method refund
     *
     * @return boolean
     */
    public function isRefundMethod()
    {
        return $this->getCode() == self::METHOD_REFUND;
    }

    /**
     * Check is method refund
     *
     * @return boolean
     */
    public function isDirectDebit()
    {
        return $this->getCode() == self::METHOD_DIRECT_DEBIT;
    }

    /**
     * Get refundable status for payment method
     *
     * @return bool|int
     */
    public function getRefundableStatus()
    {
        switch ($this->getCode()) {
            case self::METHOD_CREDIT_CARD_ONLINE : return Smile_Globalcollect_Model_Method_Abstract::API_STATUS_SENT;
        }

        return false;
    }
    
    /**
     * get additional refund fields needed
     * 
     * @param Varien_Object $newRefund
     * @param Smile_Globalcollect_Model_Method_Abstract $payment
     * @return Smile_Globalcollect_Model_Payment_Method 
     */
    public function getAdditionalRefundInfo(&$newRefund, $payment)
    {
        if ($this->isCreditCardOnline()) {
            $paymentInfo = $payment->getInfoInstance()->getAdditionalInformation('PAYMENT');
            if (!empty($paymentInfo['EFFORTID'])) {
                $newRefund->setEffortId($paymentInfo['EFFORTID']);
            }
            if (!empty($paymentInfo['ORDERID'])) {
                $newRefund->setOrderId($paymentInfo['ORDERID']);
            }
        }
        
        return $this;
    }


}
