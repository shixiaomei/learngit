<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();

$installer->getConnection()->addColumn(
    $installer->getTable('globalcollect/order_sent'), 'attempt_count', "int(5) DEFAULT 0 COMMENT 'Attempt count'"
);

$installer->endSetup();
