<?php

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();

$installer->getConnection()->addColumn(
    $installer->getTable('globalcollect/order_sent'), 'test_mode', "int(5) DEFAULT 0 COMMENT 'Is order created in Test Mode'"
);

$installer->endSetup();
