<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global Collect payment module API
 *
 */
class Smile_Globalcollect_Model_Api extends Varien_Object
{

    /* Global collect main actions */
    const ACTION_DO_PAYMENT                 = 'DO_PAYMENT';
    const ACTION_CANCEL_ORDER               = 'CANCEL_ORDER';
    const ACTION_CANCEL_REFUND              = 'CANCEL_REFUND';
    const ACTION_CANCEL_PAYMENT             = 'CANCEL_PAYMENT';
    const ACTION_DO_REFUND                  = 'DO_REFUND';
    const ACTION_SET_PAYMENT                = 'SET_PAYMENT';
    const ACTION_SET_REFUND                 = 'SET_REFUND';
    const ACTION_CANCEL_SET_PAYMENT         = 'CANCEL_SET_PAYMENT';
    const ACTION_DO_FINISH_PAYMENT          = 'DO_FINISHPAYMENT';
    const ACTION_INSERT_ORDER               = 'INSERT_ORDER';
    const ACTION_INSERT_ORDER_PAYMENT       = 'INSERT_ORDERWITHPAYMENT';
    const ACTION_MODIFY_ORDER               = 'MODIFY_ORDER';
    const ACTION_GET_ORDER                  = 'GET_ORDER';
    const ACTION_GET_RATE                   = 'GET_RATE';
    const ACTION_GET_DIRECTORY              = 'GET_DIRECTORY';
    const ACTION_GET_PAYMENT_PRODUCTS       = 'GET_PAYMENTPRODUCTS';
    const ACTION_GET_PAYMENT_PRODUCT_FIELDS = 'GET_PAYMENTPRODUCTFIELDS';
    const ACTION_GET_ORDER_STATUS           = 'GET_ORDERSTATUS';
    const ACTION_PROCESS_RETURNED           = 'PROCESS_RETURNED';
    const ACTION_PROCESS_CHALLENGED         = 'PROCESS_CHALLENGED';
    const ACTION_DO_VALIDATE                = 'DO_VALIDATE';
    const ACTION_TEST_CONNECTION            = 'TEST_CONNECTION';

    const API_RESULT_OK                     = 'OK';
    const API_RESULT_NOK                    = 'NOK';

    const PATH_PAYMENT = 'PARAMS/PAYMENT';
    const PATH_ORDER = 'PARAMS/ORDER';

    const ORDER_TYPE_RECURRING = 4;

    /**
     * Retrieve Global Collect Config
     *
     * @return Smile_Globalcollect_Model_Config
     */
    protected function _getConfig()
    {
        return Mage::getSingleton('globalcollect/config');
    }


    /**
     * Initialize request for account
     *
     *
     * @param string|int $account account name or merchant id
     * @param string $version
     * @return Varien_Simplexml_Element
     */
    protected function _initRequest()
    {
        $request = new Varien_Simplexml_Element('<XML><REQUEST></REQUEST></XML>');

        $merchantId = Mage::getStoreConfig('payment/globalcollect/merchant_id');

        $this->_addDataToRequest($request, 'META/MERCHANTID', $merchantId);
        $this->_addDataToRequest($request, 'META/IPADDRESS', $this->getServerIp());
        return $request;
    }


    /**
     * Intialize action request based on config source and passed data
     *
     * @param Varien_Simplexml_Element $request
     * @param string $action
     * @param Varien_Object $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildRequest(Varien_Simplexml_Element $request, $action, $sourceObject, $options = array())
    {
        $method = "_build".uc_words(strtolower($action), "");
        if (!method_exists($this, $method)) {
            Mage::throwException("API: invalid action {$action}");
        }
        $this->_addDataToRequest($request, 'ACTION', $action);

        $this->$method($request, $sourceObject);

        foreach ($options as $path => $value) {
            $this->_addDataToRequest($request, $path, $value);
        }

        return $this;
    }

    /**
     * add data to INSERT_ORDERWITHPAYMENT request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildInsertOrderwithpayment($request,  $sourceObject)
    {
        $this->_addDataToRequest($request, 'PARAMS/ORDER/ORDERID', $sourceObject->getIncrementId());
        $this->_addDataToRequest($request, 'PARAMS/ORDER/AMOUNT', (int) round($sourceObject->getBaseGrandTotal() * 100));
        if ($sourceObject->getShouldSaveCC()) {
            $this->_addDataToRequest($request, 'PARAMS/ORDER/ORDERTYPE', self::ORDER_TYPE_RECURRING);
        }
        $this->_addDataToRequest($request, 'PARAMS/ORDER/CURRENCYCODE', $sourceObject->getBaseCurrencyCode());

        Mage::app()->getLocale()->emulate($sourceObject->getStoreId());
        $language = Mage::app()->getLocale()->getLocale()->getLanguage();
        Mage::app()->getLocale()->revert();
        $this->_addDataToRequest($request, 'PARAMS/ORDER/LANGUAGECODE', $language);
        $this->_addDataToRequest($request, 'PARAMS/ORDER/LANGUAGE', $language);

        $this->_addDataToRequest($request, 'PARAMS/ORDER/COUNTRYCODE', strtoupper($sourceObject->getBillingAddress()->getCountry()));
        $this->_addDataToRequest($request, 'PARAMS/ORDER/MERCHANTREFERENCE', $sourceObject->getPayment()->getMethodInstance()->getMerchantReference());
        $this->_addDataToRequest($request, 'PARAMS/ORDER/IPADDRESSCUSTOMER', Mage::helper('core/http')->getRemoteAddr());

        $address = $sourceObject->getBillingAddress();

        if ($customerId = $sourceObject->getCustomerId()) {
            $this->_addDataToRequest($request, 'PARAMS/ORDER/CUSTOMERID', $customerId);
        }

        $this->_addAddressToRequest($request, $address, 'PARAMS/ORDER');

        $shippingAddress = $sourceObject->getShippingAddress();
        if (!$shippingAddress) {
            $shippingAddress = $sourceObject->getBillingAddress();
        }
        $this->_addShippingAddressToRequest($request, $shippingAddress, 'PARAMS/ORDER');

        if ($field = $sourceObject->getCustomerTaxvat()) {
            $this->_addDataToRequest($request, 'PARAMS/ORDER/VATNUMBER', $field);
        }
        if ($field = $sourceObject->getCustomerPrefix()) {
            $this->_addDataToRequest($request, 'PARAMS/ORDER/TITLE', $field);
        }

        // ORDER ITEMS
        foreach ($sourceObject->getAllVisibleItems() as $i => $item) {
            $node = $this->_addNode($request, 'PARAMS/ORDERLINES/ORDERLINE');

            $node->LINENUMBER = $i+1;
            $node->INVOICELINEDATA = $item->getName().' '.$item->getQtyOrdered().' '.$item->getPrice();
            $node->LINEAMOUNT = round($item->getRowTotal()*100);
        }

        if ($sourceObject->getTotals()) {
            $i++;
            foreach ($sourceObject->getTotals() as $total) {
                if ($total['code'] == 'subtotal' || $total['code'] == 'grand_total') {
                    continue;
                }
                $node = $this->_addNode($request, 'PARAMS/ORDERLINES/ORDERLINE');
                $node->LINENUMBER = ++$i;
                $node->INVOICELINEDATA = $total['title'];
                $node->LINEAMOUNT = round($total['value'] * 100);
            }
        } else {
            $i++;
            if ($sourceObject->getShippingAmount()) {
                $node = $this->_addNode($request, 'PARAMS/ORDERLINES/ORDERLINE');
                $node->LINENUMBER = ++$i;
                $node->INVOICELINEDATA = Mage::helper('globalcollect')->__('Shipping & handling');
                $node->LINEAMOUNT = round($sourceObject->getShippingAmount()*100);
            }

            if ($sourceObject->getTaxAmount()) {
                $node = $this->_addNode($request, 'PARAMS/ORDERLINES/ORDERLINE');
                $node->LINENUMBER = ++$i;
                $node->INVOICELINEDATA = Mage::helper('globalcollect')->__('Tax');
                $node->LINEAMOUNT = round($sourceObject->getTaxAmount()*100);
            }

            if ($sourceObject->getDiscountAmount()) {
                if ($sourceObject->getDiscountDescription()) {
                    $discountLabel = Mage::helper('globalcollect')->__('Discount (%s)', $sourceObject->getDiscountDescription());
                } else {
                    $discountLabel = Mage::helper('globalcollect')->__('Discount');
                }
                $node = $this->_addNode($request, 'PARAMS/ORDERLINES/ORDERLINE');
                $node->LINENUMBER = ++$i;
                $node->INVOICELINEDATA = $discountLabel;
                $node->LINEAMOUNT = round($sourceObject->getDiscountAmount()*100);
            }
        }


        // PAYMENT
         $this->_buildDoPayment($request,  $sourceObject, $language);

        return $this;
    }

    /**
     * add data to DO_PAYMENT request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildDoPayment($request,  $sourceObject, $language = null)
    {
        if (!$language) {
            Mage::app()->getLocale()->emulate($sourceObject->getStoreId());
            $language = Mage::app()->getLocale()->getLocale()->getLanguage();
            Mage::app()->getLocale()->revert();
        }

        $token = $sourceObject->getToken();
        if ($token) {
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ORDERID', $token->getOrderId());
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/MERCHANTREFERENCE',
                    $sourceObject->getPayment()->getMethodInstance()->getMerchantReference());
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/EFFORTID', $token->getEffortId());
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ATTEMPTID', $token->getAttemptId());
        } else {
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/PAYMENTPRODUCTID',
                $sourceObject->getPayment()->getAdditionalInformation('payment_product_id'));
        }

        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/AMOUNT',
                (int) round($sourceObject->getBaseGrandTotal() * 100));
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/CURRENCYCODE', $sourceObject->getBaseCurrencyCode());

        $this->_addAddressToRequest($request, $sourceObject->getBillingAddress(), 'PARAMS/PAYMENT');

        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/LANGUAGECODE', $language);
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/LANGUAGE', $language);
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/COUNTRYCODE',
                strtoupper($sourceObject->getBillingAddress()->getCountry()));

        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/HOSTEDINDICATOR',
                $sourceObject->getPayment()->getMethodInstance()->isHosted());
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/RETURNURL',
                $sourceObject->getPayment()->getMethodInstance()->getReturnUrl());

        if ($sourceObject->getPayment()->getMethodInstance()->getSelectedPaymentMethod()->isCreditCardOnline()) {
            $mode = ($this->_getConfig()->getAuthenticationMode() == Smile_Globalcollect_Model_Source_Payment_Action::PAYMENT_ACTION_AUTHORIZE ? 7 : 0);
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ACCEPTNEEDEDINDICATOR', $mode);
        }

        return $this;
    }

    /**
     * add data to GET_ORDERSTATUS request
     *
     * @param Varien_Simplexml_Element $request
     * @param Varien_Object $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildGetOrderstatus($request,  $sourceObject)
    {
        if (!$sourceObject->getIncrementId()) {
            Mage::throwException("API: invalid order ID");
        }
        $this->_addDataToRequest($request, 'META/VERSION', "2.0");
        $this->_addDataToRequest($request, 'PARAMS/ORDER/ORDERID', $sourceObject->getIncrementId());
        $effortId = $sourceObject->getEffortId();
        if ($effortId) {
            $this->_addDataToRequest($request, 'PARAMS/ORDER/EFFORTID', $effortId);
        }

        return $this;
    }


    /**
     * add data to GET_PAYMENTPRODUCTS request
     *
     * @param Varien_Simplexml_Element $request
     * @param Varien_Object $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildGetPaymentproducts($request,  $sourceObject)
    {
        $this->_addDataToRequest($request, 'PARAMS/GENERAL/LANGUAGECODE', $sourceObject->getLanguageCode());
        $this->_addDataToRequest($request, 'PARAMS/GENERAL/COUNTRYCODE', $sourceObject->getCountryCode());
        $this->_addDataToRequest($request, 'PARAMS/GENERAL/CURRENCYCODE', $sourceObject->getCurrencyCode());

        return $this;
    }

    /**
     * add data to SET_PAYMENT request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildSetPayment($request,  $sourceObject, $language = null)
    {
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ORDERID', $sourceObject->getIncrementId());
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/PAYMENTPRODUCTID', $sourceObject->getPayment()->getAdditionalInformation('payment_product_id'));

        return $this;
    }

    /**
     * add data to PROCESS_CHELENGED request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildProcessChallenged($request,  $sourceObject, $language = null)
    {
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ORDERID', $sourceObject->getIncrementId());

        return $this;
    }

    /**
     * add data to CANCEL_PAYMENT request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildCancelPayment($request,  $sourceObject, $language = null)
    {
        $payment = $sourceObject->getPayment()->getAdditionalInformation('PAYMENT');

        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ORDERID', $sourceObject->getIncrementId());
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/EFFORTID', isset($payment['EFFORTID'])?$payment['EFFORTID']:1);
        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ATTEMPTID', isset($payment['ATTEMPTID'])?$payment['ATTEMPTID']:1);

        return $this;
    }

    /**
     * add data to PROCESS_RETURNED request
     *
     * @param Varien_Simplexml_Element $request
     * @param Varien_Object $sourceObject
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildProcessReturned($request,  $sourceObject, $language = null)
    {
        if (!$sourceObject->getIncrementId()) {
            Mage::throwException("API: invalid order ID");
        }

        $this->_addDataToRequest($request, 'PARAMS/PAYMENT/ORDERID', $sourceObject->getIncrementId());

        return $this;
    }

    /**
     *
     * @param Varien_Simplexml_Element $request
     * @param Varien_Object $sourceObject
     * @param string $language
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _buildDoRefund($request,  $sourceObject, $language = null)
    {
        foreach ($sourceObject->getData() as $row => $value) {
            $this->_addDataToRequest($request, 'PARAMS/PAYMENT/'.  strtoupper(str_replace('_', '', $row)), $value);
        }

        return $this;
    }

    /**
     * Add address data to request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order_Address $action
     * @param string $path
     *
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _addAddressToRequest($request, $address, $path = 'PARAMS/ORDER') {
        // ZIP (MAX LENGTH: 10)
        $zipcode = substr(preg_replace("/[^ a-zA-Z0-9]+/","",$address->getPostcode()),0,10);
        // STREET (MAX LENGTH: 50)
        $street = substr($address->getStreetFull(),0,50);
        // FIRSTNAME (MAX LENGTH: 15)
        $firstname = substr($address->getFirstname(),0,15);
        // LASTNAME (MAX LENGTH: 15)
        $lastname = substr($address->getLastname(),0,15);
        // CITY (MAX LENGTH: 40)
        $city = substr($address->getCity(),0,40);

        $this->_addDataToRequest($request, $path.'/FIRSTNAME', $firstname);
        $this->_addDataToRequest($request, $path.'/SURNAME', $lastname);
        $this->_addDataToRequest($request, $path.'/STREET', $street);
        $this->_addDataToRequest($request, $path.'/CITY', $city);
        $this->_addDataToRequest($request, $path.'/ZIP', $zipcode);
        if ($field = $address->getRegion()) {
            // STATE (MAX LENGTH: 35)
            $region = substr($field,0,35);
            $this->_addDataToRequest($request, $path.'/STATE', $region);
        }
        if ($field = $address->getCompany()) {
            $this->_addDataToRequest($request, $path.'/COMPANYNAME', $field);
        }

        $this->_addDataToRequest($request, $path.'/EMAIL', $address->getOrder()->getCustomerEmail());

        if ($field = $address->getOrder()->getCustomerDob()) {
            $this->_addDataToRequest($request, $path.'/BIRTHDATE', $field);
        }
        return $this;
    }

    /**
     * Add shipping address data to request
     *
     * @param Varien_Simplexml_Element $request
     * @param Mage_Sales_Model_Order_Address $action
     * @param string $path
     *
     * @return Smile_Globalcollect_Model_Api
     */
    protected function _addShippingAddressToRequest($request, $address, $path = 'PARAMS/ORDER') {
        // ZIP (MAX LENGTH: 10)
        $zipcode = substr(preg_replace("/[^ a-zA-Z0-9]+/","",$address->getPostcode()),0,10);
        // STREET (MAX LENGTH: 50)
        $street = substr($address->getStreetFull(),0,50);
        // FIRSTNAME (MAX LENGTH: 15)
        $firstname = substr($address->getFirstname(),0,15);
        // LASTNAME (MAX LENGTH: 15)
        $lastname = substr($address->getLastname(),0,15);
        // SHIPPINGCITY (MAX LENGTH: 40)
        $shippingCity = substr($address->getCity(),0,40);

        $this->_addDataToRequest($request, $path.'/SHIPPINGFIRSTNAME', $firstname);
        $this->_addDataToRequest($request, $path.'/SHIPPINGSURNAME', $lastname);
        $this->_addDataToRequest($request, $path.'/SHIPPINGSTREET', $street);
        $this->_addDataToRequest($request, $path.'/SHIPPINGZIP', $zipcode);
        $this->_addDataToRequest($request, $path.'/SHIPPINGCITY', $shippingCity);
        $this->_addDataToRequest($request, $path.'/SHIPPINGCOUNTRYCODE', $address->getCountryId());
        if ($field = $address->getRegion()) {
            $region = substr($field,0,35);
            $this->_addDataToRequest($request, $path.'/SHIPPINGSTATE', $region);
        }
        return $this;
    }
    /**
     * Add data to request
     *
     * @param Varien_Simplexml_Element $request
     * @param string $key
     * @param string $value
     * @return Smile_Globalcollect_Model_Api_Gc
     */
    protected function _addDataToRequest(Varien_Simplexml_Element $request, $key, $value)
    {
        $key = 'REQUEST/' . $key;
        if($value !== '' && $value !== null) {
            $request->setNode($key, $value, true);
        }
        return $this;
    }

    /**
     * Add placeholder
     *
     * @param Varien_Simplexml_Element $request
     * @param string $path
     * @return Varien_Simplexml_Element
     */
    protected function _addNode($request, $path)
    {
        $node = $request->REQUEST;
        $arr = explode('/', $path);
        $last = count($arr)-1;

        foreach ($arr as $i => $nodeName) {
            if (!isset($node->$nodeName) || $i === $last) {
                $node = $node->addChild($nodeName);
            } else {
                $node = $node->$nodeName;
            }
        }
        return $node;
    }

    /**
     * Retrieve server ip address
     *
     * @return string
     */
    public function getServerIp()
    {
        $serverIp = Mage::helper('core/http')->getServerAddr();

        return $serverIp;
    }


    /**
     * Test current connection from current server ip address
     *
     * @return boolean
     */
    public function testConnection($mercantId, $gatewayUrl)
    {
        $request = $this->_initRequest($mercantId);
        $this->_addDataToRequest($request, 'ACTION', self::ACTION_TEST_CONNECTION);
        $rawResponse = $this->_postRequest($gatewayUrl, $request);
        if (strpos($rawResponse, '<XML>') === false || strpos($rawResponse, '</XML>') === false) {
            return false;
        }

        $xmlResponse = simplexml_load_string($rawResponse, 'Varien_Simplexml_Element');
        return $this->isResponseSuccessfull($xmlResponse);
    }


    /**
     * Call Global Collect xml api request
     *
     * @param string $action
     * @param string $account
     * @param Varien_Object $object
     * @param array $options should be an array with keys as name of variable
     * @return Varien_Simplexml_Element|boolean
     */
    public function call($action, $object, $options = array())
    {
        $gatewayUrl = Mage::getStoreConfig('payment/globalcollect/gateway_url');
        if (!$gatewayUrl) {
            return false;
        }

        $request = $this->_initRequest();

        $this->_buildRequest($request, $action, $object, $options);

        $rawResponse = $this->_postRequest($gatewayUrl, $request);

        if (strpos($rawResponse, '<XML>') === false || strpos($rawResponse, '</XML>') === false) {
            return false;
        }

        $xmlResponse = simplexml_load_string($rawResponse, 'Varien_Simplexml_Element');

        if ($this->_getConfig()->isDebug()) {
            Mage::log($action, 0, "global_collect.log");
            Mage::log($request->asNiceXml(), 0, "global_collect.log");
            Mage::log(var_export($xmlResponse->descend('REQUEST/RESPONSE'), true), 0, "global_collect.log");
        }

        return $xmlResponse;
    }


    /**
     * Post request to global collect and return result as string
     *
     * @param string $gatewayUrl
     * @param Varien_Simplexml_Element $request
     * @return string
     */
    protected function _postRequest($gatewayUrl, $request)
    {
        // use Varien curl adapter
        $http = new Varien_Http_Adapter_Curl();
        // no need to verify SSL for test mode //
        if ($this->_getConfig()->getField('test_mode')) {
            $http->setOptions(array(CURLOPT_SSL_VERIFYHOST => false, CURLOPT_SSL_VERIFYPEER => false));
        }
        $http->write(
            Zend_Http_Client::POST,
            $gatewayUrl,
            '1.1',
            array(),
            $request->asNiceXml()
        );

        // read the remote file
        $data = $http->read();
        $data = preg_split('/^\r?$/m', $data, 2);

        $response = trim($data[1]);
        return $response;
    }


    /**
     * Check response is successfull
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return boolean
     */
    public function isResponseSuccessfull($response)
    {
        if (!$response instanceof Varien_Simplexml_Element) {
            if ($this->_getConfig()->isDebug()) {
                Mage::log("ERROR:".var_export($response, true), 0, 'global_collect.log');
            }
            return false;
        }

        $result = (string) $response->descend('REQUEST/RESPONSE/RESULT');

        if ($result === self::API_RESULT_OK) {
            return true;
        }

        return false;
    }

    /**
     * Check response is error message
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return boolean
     */
    public function isResponseErrorMessage($response)
    {
        if (!$response instanceof Varien_Simplexml_Element) {
            return false;
        }

        $result = (string) $response->descend('REQUEST/RESPONSE/RESULT');

        if ($result === self::API_RESULT_NOK) {
            return true;
        }

        return false;
    }

    /**
     * Retrieve error message from api response
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return string|boolean
     */
    public function getResponseErrorMessage($response)
    {
        if (!$this->isResponseErrorMessage($response)) {
            return false;
        }

        return (string)$response->descend('REQUEST/RESPONSE/ERROR/MESSAGE');
    }

    /**
     * Retrive error code from api response
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return string|boolean
     */
    public function getResponseErrorCode($response)
    {
        if (!$this->isResponseErrorMessage($response)) {
            return false;
        }

        return (string)$response->descend('REQUEST/RESPONSE/ERROR/CODE');
    }

    /**
     * Retrieve response item, returned from global collect
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @param string $key
     * @param boolean $isList
     * @return array|boolean
     */
    public function getResponseItem($response, $key, $isList = false, $asNode = false)
    {
//        if (!$this->isResponseSuccessfull($response)) {
//            return false;
//        }

        $node = $response->descend('REQUEST/RESPONSE');

        if (!$isList) {
            if (isset($node->{$key})) {
                return ($asNode ? $node->{$key} : $node->{$key}->asCanonicalArray());
            }
        }

        $result = array();

        foreach ($node->children() as $childKey => $child) {
            if ($childKey === $key) {
                $result[] = ($asNode ? $child : $child->asCanonicalArray());
            }
        }

        return $result;
    }

    /**
     * Throws global collect exception
     *
     * @param string $message
     * @throws Smile_Globalcollect_Exception
     */
    public function throwException($message)
    {
        throw Mage::exception('Smile_Globalcollect', $message);
    }

    public function getPaymentPath()
    {
        return self::PATH_PAYMENT;
    }

    public function getOrderPath()
    {
        return self::PATH_ORDER;
    }
}
