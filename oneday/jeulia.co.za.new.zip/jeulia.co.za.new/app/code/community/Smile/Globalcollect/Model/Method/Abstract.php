<?php
/**
 * Disclaimer
 * All trademarks, service marks and trade names referenced in this material
 * are the property of their respective owners This software is not intended
 * to be a complete solution of all applicable rules, policies and procedures.
 * The matters referenced are subject to change from time to time, and
 * individual circumstances may vary. Global Collect Services B.V. shall not
 * be responsible for any inaccurate or incomplete coding.
 *
 * Global Collect Services B.V. has given extensive attention to the quality
 * of the software but makes no warranties or representations about the accuracy
 * or completeness of it. Neither Global Collect Services B.V. nor any of its
 * affiliates shall be liable for any costs, losses and/or damages arising out
 * of access to or use of this software. Because of the complexity of the process
 * and the right of Banks to alter conditions, this software can only serve
 * as a quick-start in development is subject to further modifications.
 *
 * The Magento extension was developed as a generic solution.
 * In the event that the cartridge is modified by a user in any way,
 * Global Collect Services B.V. shall not be responsible for any damages that
 * are caused by the modified extension. Global Collect Services B.V. makes
 * no warranties or representations about the use or operation of the extension.
 * Neither Global Collect Services B.V. nor any of its affiliates shall be
 * liable for any costs, losses and/or damages arising out of access to
 * or use of the extension.
 *
 * Suggestions
 * Suggestions regarding the extension are welcome and may be forwarded to
 * global.partnerships@globalcollect.com
 *
 * @package     Smile_Globalcollect
 * @copyright   Copyright © 2012 Global Collect Services B.V.
 */

/**
 * Global collect payment method abstract
 *
 */
abstract class Smile_Globalcollect_Model_Method_Abstract extends Mage_Payment_Model_Method_Abstract
{
    /**
     * Allowed globalcollect/payment_method for this payment methods
     * @var array
     */
    protected $_allowedMethods = array();
    
    /**
     * Auto join allowed methods flag
     * @var boolean
     */
    protected $_joinAllowedMethods = true;
    
    const API_STATUS_PENDING_VERIFICATION = 650;

    /**
     * Global collect pending statuses
     */
    const API_STATUS_PENDING_MERCHANT = 20;
    const API_STATUS_PENDING_GLOBALCOLLECT = 25;
    const API_STATUS_PENDING_AT_BANK = 50;
    const API_STATUS_PENDING_CONSUMER = 55;
    const API_STATUS_OPEN = 60;
    const API_STATUS_PENDING_BANK = 65;
    const API_STATUS_INDOUBT = 70;

    /**
     * Global collect rejected statuses
     */
    const API_STATUS_REJECTED= 100;
    const API_STATUS_REJECTED_AT_BANK = 120;
    const API_STATUS_CANCELLED_AT_BANK = 125;
    const API_STATUS_FAILED = 130;
    const API_STATUS_EXPIRED_AT_BANK = 140;
    const API_STATUS_TIMEDOUT_AT_BANK = 150;
    const API_STATUS_DENIED = 160;
    const API_STATUS_AUTHORIZATION_EXPIRED = 170;
    const API_STATUS_ENROLLMENT_EXPIRED = 172;
    const API_STATUS_VALIDATION_EXPIRED = 175;
    const API_STATUS_3D_SECURE_INCOMPLETE = 180;

    /**
     * Global collect authenticated statuses
     */
    const API_STATUS_AUTHENTICATED = 200;
    const API_STATUS_UNABLE_TO_AUTHENTICATE = 220;
    const API_STATUS_NOT_3D_SECURE = 230;
    const API_STATUS_AUTHENTICATE_3D_SECURE_INCOMPLETE = 280;
    const API_STATUS_AUTHORIZATION_TESTED = 300;

    /**
     * Global collect authenticate failed statuses
     */
    const API_STATUS_NO_AUTHORIZATION_NOT_AUTHENTICATED = 320;
    const API_STATUS_NO_AUTHORIZATION_AUTHENTICATED = 350;

    /**
     * Global collect authorized statatuses
     */
    const API_STATUS_REVISED = 400;
    const API_STATUS_CHALLENGED = 525;
    const API_STATUS_REFERRED = 550;
    const API_STATUS_AUTHORIZED = 600;

    /**
     * Global collect settled statatuses
     */
    const API_STATUS_READY = 800;
    const API_STATUS_READY_TO_SEND = 850;
    const API_STATUS_SENT = 900;
    const API_STATUS_REFUND_PROCESSED = 900;
    const API_STATUS_INVOICE_SENT = 950;
    const API_STATUS_SETTELMENT_PROCESSING = 975;
    const API_STATUS_PAID = 1000;
    const API_STATUS_ACCOUNT_DEBITED = 1010;
    const API_STATUS_PAYMENT_CORRECTED = 1020;
    const API_STATUS_COLLECTED = 1050;

    /**
     * Global collect captured reject statatuses
     */
    const API_STATUS_REJECTED_START = 1100;
    const API_STATUS_REJECTED_END = 1210;
    const API_STATUS_REQUESTED_CHARGEBACK = 1030;
    const API_STATUS_CHARGEBACK_START = 1250;
    const API_STATUS_CHARGEBACK_END = 1520;

    /**
     * Global collect refund statatuses
     */
    const API_STATUS_REDUNDED = 1800;
    const API_STATUS_CORRECTED_REDUNDED = 1810;
    const API_STATUS_REDUND_REFUSED = 1810;

    /**
     * Global collect canceled statatuses
     */
    const API_STATUS_CANCELLED = 99999;


    /**
     * Global collect payment API model
     *
     * @var Smile_Globalcollect_Model_Api
     */
    protected $_api = null;

    /**
     * Payment flags and data manipulation model
     *
     * @var Smile_Globalcollect_Model_Payment
     */
    protected $_payment = null;


    /**
     * Available payment methods
     *
     * @var Smile_Globalcollect_Model_Mysql4_Payment_Method_Collection
     */
    protected $_paymentMethods = null;

    /**
     * Available payment products
     *
     * @var Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    protected $_paymentProducts = null;

    /**
     * Selected payment product
     *
     * @var Smile_Globalcollect_Model_Payment_Product
     */
    protected $_selectedPaymentProduct = null;

    /**
     * Selected payment method
     *
     * @var Smile_Globalcollect_Model_Payment_Method
     */
    protected $_selectedPaymentMethod = null;

    /**
     * Selected payment token
     *
     * @var Smile_Globalcollect_Model_Token
     */
    protected $_selectedToken = null;


    protected $_isHosted = true;

    /**
     * Default parameters for globalcollect payment method
     *
     */
    protected $_isGateway               = true;
    protected $_canAuthorize            = false;
    protected $_canCapture              = true;
    protected $_canCapturePartial       = false;
    protected $_canRefund               = true;
    protected $_canRefundInvoicePartial = true;
    protected $_canVoid                 = true;
    protected $_canUseInternal          = true;
    protected $_canUseCheckout          = true;
    protected $_canUseForMultishipping  = false;
    protected $_isInitializeNeeded      = true;


    public function isHosted() {
        return $this->_isHosted;
    }

    /**
     * Fill additional payment fields for api request
     *
     * @return array
     */
    protected function _getAdditionalPaymentFields()
    {
        return array();
    }

    protected function _addRequiredFields(&$options)
    {
        // add customer method fields from checkout page to request
        $path = $this->getApi()->getPaymentPath();
        $fields = $this->getInfoInstance()->getAdditionalInformation('method_fields');
        if (is_array($fields) && isset($fields[$this->getSelectedPaymentProduct()->getId()])) {
            foreach($fields[$this->getSelectedPaymentProduct()->getId()] as $name => $value) {
                $options[$path."/".$name] = $value;
            }
        }

        // @TODO: get required fields for each payment product in product class
        // hardcoded for Direct Debit for now since none other product has required fields
        if ($this->getSelectedPaymentMethod()->isDirectDebit()) {
            $options[$path."/DIRECTDEBITTEXT"] = $this->_getConfig()->getField('directdebit_text');

            if (!$this->_getConfig()->getField('directdebit_easy_country')
                    && in_array(strtoupper($this->getOrder()->getBillingAddress()->getCountry()),
                            array('AT', 'DE', 'ES', 'NL'))
            ) {
                $options[$this->getApi()->getOrderPath().'/MANDATE'] = 'PRESENT';
            }
        }

        return $this;
    }

    /**
     * Process api response after inserting order
     *
     * @param array $response
     * @param Varien_Object $stateObject
     */
    abstract protected function _responseInsertOrder($response, &$stateObject);

    /**
     * Format CC expiry date to GC format MMYY
     *
     * @return string
     */
    public function getCCExpiryDate()
    {
        $month = $this->getInfoInstance()->getCcExpMonth();
        $year = $this->getInfoInstance()->getCcExpYear();
        return Mage::helper('globalcollect')->formatCcExpiryDate($month, $year);
    }

    /**
     * Retrieve global collect config model
     *
     * @return Smile_Globalcollect_Model_Config
     */
    protected function _getConfig()
    {
        return Mage::getSingleton('globalcollect/config');
    }

    /**
     * Retrieve payment flags and manipulation model
     *
     * @return Smile_Globalcollect_Model_Payment
     */
    protected function _getPayment()
    {
        if ($this->_payment=== null) {
            $this->_payment = Mage::getSingleton('globalcollect/payment');
        }

        return $this->_payment;
    }


    /**
     * Generate return url for this payment method
     *
     * @param array $params
     * @return string
     */
    public function getReturnUrl($options = array())
    {
        $params['order_id'] = $this->getInfoInstance()->getParentId();

        $params += $options;

        if (!Mage::app()->getStore()->isAdmin()) {
            /* @var $urlModel Mage_Core_Model_Url */
            $urlModel = Mage::getModel('core/url');
            $urlModel->setStore($this->getStoreId());
            $returnUrl = $urlModel->getUrl('globalcollect/gateway/return', $params);
        } else {
            $returnUrl = Mage::getSingleton('adminhtml/url')->getUrl('globalcollect/adminhtml_method/redirect', $params);
        }
        return $returnUrl;
    }

    /**
     * Retrieve Global Collect API model
     *
     * @return Smile_Globalcollect_Model_Api
     */
    public function getApi()
    {
        if ($this->_api === null) {
            $this->_api = Mage::getSingleton('globalcollect/api');
        }

        return $this->_api;
    }


    /**
     * Check is api response is successfull result
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return boolean
     */
    public function isApiResponseSuccessfull($response)
    {
        return $this->getApi()->isResponseSuccessfull($response);
    }

    /**
     * Check is api response has error message
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @return boolean
     */
    public function isApiResponseErrorMessage($response)
    {
        return $this->getApi()->isResponseErrorMessage($response);
    }

    /**
     * Retrieve response item from global collect api xml
     *
     * @param Varien_Simplexml_Element|boolean $response
     * @param string $key
     * @param boolean $isList
     * @return array|boolean
     */
    public function getApiResponseItem($response, $key, $isList = false)
    {
        return $this->getApi()->getResponseItem($response, $key, $isList);
    }

    /**
     * Retrieve payment products information depends on quote/order
     *
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Product_Collection
     */
    public function getPaymentProducts()
    {
        if ($this->_paymentProducts === null) {
            $infoInstance = $this->getInfoInstance();
            if ($infoInstance instanceof Mage_Sales_Model_Order_Payment) {
                $amount = $infoInstance->getOrder()->getBaseGrandTotal();
            } elseif ($infoInstance instanceof Mage_Sales_Model_Quote_Payment) {
                $amount = $infoInstance->getQuote()->getBaseGrandTotal();
            } else {
                $this->throwException(Mage::helper('globalcollect')->__('Unable to retrieve info instance'));
            }

            $this->_paymentProducts = Mage::getSingleton('globalcollect/payment')
                ->getPaymentProducts($this, $amount);

            $this->_paymentProducts->addFieldToFilter('main_table.payment_product_id', array(
                'in'=> $this->_getConfig()->getAllowedPaymentProducts($this->getCode())
            ));
            
            if ($this->_allowedMethods && $this->_joinAllowedMethods) {
                $this->_paymentProducts->addMethodToFilter($this->_allowedMethods);
            }
        }

        return $this->_paymentProducts;
    }

    /**
     * Retrieve payment methods information depends on quote/order
     *
     * @return Smile_Globalcollect_Model_Mysql4_Payment_Method_Collection
     */
    public function getPaymentMethods()
    {
        if ($this->_paymentMethods === null) {
            $this->_paymentMethods = Mage::getSingleton('globalcollect/payment')
                ->getPaymentMethods($this->getLanguage()/*, $this->getPaymentProducts()*/);
        }

        return $this->_paymentMethods;
    }

    /**
     * Retrieve selected payment product
     *
     * @return Smile_Globalcollect_Model_Payment_Product|boolean
     */
    public function getSelectedPaymentProduct()
    {
        if ($this->_selectedPaymentProduct === null) {
            $paymentProductId = $this->getInfoInstance()->getAdditionalInformation('payment_product_id');
            if ($paymentProductId) {
                $paymentProduct = Mage::getModel('globalcollect/payment_product')->load($paymentProductId);
                if ($paymentProduct->getId()) {
                    $this->_selectedPaymentProduct = $paymentProduct;
                    return $this->_selectedPaymentProduct;
                }
            }
            return false;
        }

        return $this->_selectedPaymentProduct;
    }

    /**
     * Retrieve selected payment token
     *
     * @return Smile_Globalcollect_Model_Payment_Product|boolean
     */
    public function getSelectedToken()
    {
        if ($this->_selectedToken === null) {
            $tokenId = $this->getInfoInstance()->getAdditionalInformation('token_id');
            if ($tokenId) {
                $token = Mage::getModel('globalcollect/token')->load($tokenId);
                if ($token->getId()) {
                    $this->_selectedToken = $token;
                }
            }
        }

        return $this->_selectedToken;
    }

    /**
     * Retrieve selected payment method
     *
     * @return Smile_Globalcollect_Model_Payment_Method|boolean
     */
    public function getSelectedPaymentMethod()
    {
        if ($this->_selectedPaymentMethod === null) {
            $paymentMethodId = $this->getInfoInstance()->getAdditionalInformation('payment_method_id');
            if ($paymentMethodId) {
                $paymentMethod = Mage::getModel('globalcollect/payment_method')->load($paymentMethodId);
                if ($paymentMethod->getId()) {
                    $this->_selectedPaymentMethod = $paymentMethod;
                    return $this->_selectedPaymentMethod;
                }
            }
            return false;
        }

        return $this->_selectedPaymentMethod;
    }

    /**
     * Retrieve order status from state
     *
     * @param string $state
     * @return boolean
     */
    public function getStatusFromState($state)
    {
        if ($state === Mage_Sales_Model_Order::STATE_PENDING_PAYMENT) {
            $status = $this->_getConfig()->getField('order_status');

            if ($status) {
                return $status;
            }
        } elseif ($state === Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW) {
            $status = $this->_getConfig()->getField('fraud_order_status');

            if ($status) {
                return $status;
            }
        }
        return Mage::getSingleton('sales/order_config')->getStateDefaultStatus($state);
    }

    /**
     * Check whether payment method can be used
     * @param Mage_Sales_Model_Quote $quote
     * @return bool
     */
    public function isAvailable($quote = null)
    {
        if (Mage::app()->getStore()->isAdmin()) {
            return false;
        }

        $result = parent::isAvailable($quote);
//由于本站使用GC属于外嵌入式，此处原本要使用getinfoinstance去获取已加入购物车物品总价，但我们的规则是先下单再支付，
//所以quote为空  导致其无法获取到info_instance信息，报错，此处判断状态是否可用，其实可以单纯取出已开放的收款项，进行处理。屏蔽掉是做简单暴力的方法。
//        if ($result) {
//            if ($quote !== null && !$this->hasInfoInstance()) {
//                // We need to emulate info instance enviroment
//                $this->setInfoInstance($quote->getPayment());
//                $this->setInfoInstanceChanged(true);
//            }
//
//            $result = $this->getPaymentProducts()->count() > 0;
//
//            if ($quote !== null && $this->getInfoInstanceChanged()) {
//                $this->unsInfoInstance();
//                $this->unsInfoInstanceChanged();
//            }
//        }

        return $result;
    }

    /**
     * Retrieve store id from info instance if applicable
     *
     * @return null|int
     */
    public function getStoreId()
    {
        if ($this->hasData('info_instance')) {
            if ($this->getInfoInstance() instanceof Mage_Sales_Model_Order_Payment) {
                return $this->getInfoInstance()->getOrder()->getStoreId();
            } else {
                return $this->getInfoInstance()->getQuote()->getStoreId();
            }
        }

        return $this->_getData('store_id');
    }

    /**
     * Return increment id of order
     *
     * @return string
     */
    public function getIncrementId()
    {
        if ($this->getOrder()) {
            return $this->getOrder()->getIncrementId();
        }

        return null;
    }

    /**
     * Retrieve country id from info instance if applicable
     *
     * @return null|int
     */
    public function getCountryId()
    {
        if ($this->hasData('info_instance')) {
            if ($this->getInfoInstance() instanceof Mage_Sales_Model_Order_Payment) {
                return $this->getInfoInstance()->getOrder()->getBillingAddress()->getCountryId();
            } else {
                return $this->getInfoInstance()->getQuote()->getBillingAddress()->getCountryId();
            }
        }

        return $this->_getData('country_id');
    }

    /**
     * Retrieve country id from info instance if applicable
     *
     * @return null|int
     */
    public function getCurrencyCode()
    {
        if ($this->hasData('info_instance')) {
            if ($this->getInfoInstance() instanceof Mage_Sales_Model_Order_Payment) {
                return $this->getInfoInstance()->getOrder()->getBaseCurrencyCode();
            } else {
                return $this->getInfoInstance()->getQuote()->getStore()->getBaseCurrencyCode();
            }
        }

        return $this->_getData('currency_code');
    }

    /**
     * Return language for displaying titles for customer
     *
     * @return string
     */
    public function getLanguage()
    {
        if (Mage::app()->getStore()->getId() !== $this->getStoreId()) {
            Mage::app()->getLocale()->emulate($this->getStoreId());
        }

        $locale = Mage::app()->getLocale()->getLocale();

        if (Mage::app()->getStore()->getId() !== $this->getStoreId()) {
            Mage::app()->getLocale()->revert();
        }

        return $locale->getLanguage();
    }

    /**
     * Assigns data to info object
     *
     * @param array $data
     * @return Smile_Globalcollect_Model_Method_Abstract
     * @throws Smile_Globalcollect_Exception_Validation
     */
    public function assignData($data)
    {
        parent::assignData($data);

        if (isset($data['payment_product_id'])) {
            // in case of saved CC payment_product_id will be 'token_{token_id}'
            if(isset($data[$data['payment_product_id']])) {
                $token = Mage::getModel('globalcollect/token')->validate($data[$data['payment_product_id']]);

                $this->getInfoInstance()->setAdditionalInformation('token_id', $token->getId());
                $this->getInfoInstance()->setAdditionalInformation('payment_product_id', $token->getPaymentProductId());
                $this->getInfoInstance()->setAdditionalInformation('payment_method_id',
                        Mage::helper('globalcollect')->getCreditCardMethodId());
            } else {
                $this->getInfoInstance()->setAdditionalInformation('token_id', null);
                $paymentProduct = $this->getPaymentProducts()->getItemById($data['payment_product_id']);
                if (!$paymentProduct) {
                    Mage::throwException(Mage::helper('globalcollect')->__('Please select Payment Product'));
                }
                $this->getInfoInstance()->setAdditionalInformation('payment_product_id', $paymentProduct->getId());
                $this->getInfoInstance()->setAdditionalInformation('payment_method_id',
                        $paymentProduct->getPaymentMethodId());
            }
        } elseif (!$this->getInfoInstance()->getAdditionalInformation('payment_product_id')
                || !$this->getInfoInstance()->getAdditionalInformation('payment_method_id')
        ) {
            Mage::throwException(Mage::helper('globalcollect')->__('Please sekect Payment Product'));
        }
        if (isset($data['method_fields']) && is_array($data['method_fields'])) {
            $this->getInfoInstance()->setAdditionalInformation('method_fields', $data['method_fields']);
        }
        if (isset($data['save_cc_data']) && $data['save_cc_data']) {
            $this->getInfoInstance()->setAdditionalInformation('save_cc_data', true);
        } else {
            $this->getInfoInstance()->setAdditionalInformation('save_cc_data', false);
        }
        return $this;
    }

    /**
     * Validates payment method data
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function validate()
    {
        parent::validate();
        if (!$this->getSelectedPaymentProduct()) {
            $this->throwException(Mage::helper('globalcollect')->__('Please select Payment Method'));
        }

        return $this;
    }


    /**
     * Initializes payment process flow depeinging of GlobalCollect configuration
     *
     * @param string $paymentAction
     * @param Varien_Object $stateObject
     * @return  Smile_Globalcollect_Model_Method_Abstract
     */
    public function initialize($paymentAction, $stateObject)
    {
        $this->getInfoInstance()->setBaseAmountAuthorized($this->getOrder()->getBaseTotalDue());
        $this->getInfoInstance()->setAmountAuthorized($this->getOrder()->getTotalDue());

        $options = $this->_getAdditionalPaymentFields();
        $this->_addRequiredFields($options);

        $action = Smile_Globalcollect_Model_Api::ACTION_INSERT_ORDER_PAYMENT;
        $section = 'ROW';

        $object = ($this->hasData('info_instance') ? $this->getInfoInstance()->getOrder() : $this);

        $token = false;
        if ($this->getSelectedPaymentMethod()->isCreditCardOnline()) {
            $object->setShouldSaveCC($this->getInfoInstance()->getAdditionalInformation('save_cc_data'));

            $tokenId = $this->getInfoInstance()->getAdditionalInformation('token_id');
            if ($tokenId) {
                $token = Mage::getModel('globalcollect/token')->load($tokenId);
                if ($token->getId() && $token->isValidFor(Mage::getSingleton('customer/session')->getCustomer())) {
                    $token->setEffortId($token->getEffortId() + 1);
                    $token->setAttemptId($this->getAttemptId());
                    $object->setToken($token);
                    $action = Smile_Globalcollect_Model_Api::ACTION_DO_PAYMENT;
                }
            }
        }


        $response = $this->getApi()->call($action, $object, $options);

        $error_code = $this->getApi()->getResponseErrorCode($response);
        if (!$this->getApi()->isResponseSuccessfull($response) && $error_code)
        {
            if ($error_code == 400120) {
                // MERCHANTREFERENCE ALREADY FINAL
                $action = Smile_Globalcollect_Model_Api::ACTION_GET_ORDER_STATUS;
                $section = 'STATUS';
                $response = $this->getApi()->call($action, $object);
                Mage::getSingleton('checkout/session')->setGCOrderProcessed(true);
            } elseif ($error_code == 300620) {
                // MERCHANTREFERENCE ALREADY EXISTS
                $this->addAttemptId();
                $this->getInfoInstance()->setAdditionalInformation('MERCHANTREFERENCE', $this->getMerchantReference(true));
                $response = $this->getApi()->call($action, $object, $options);
            }
        }

        if (!$this->getApi()->isResponseSuccessfull($response)) {
            if (!$this->getApi()->isResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
            }

            $error = $this->getApiResponseItem($response, 'ERROR');
            $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
        }

        if (!$this->_getPayment()->isOrderSent($this->getIncrementId())) {
            $this->_getPayment()->setOrderSent($this->getInfoInstance()->getOrder()->getIncrementId());
        }

        if ($token && $token->getId()) {
            $token->save();
        }

        $payment = $this->getApiResponseItem($response, $section);

        $statusId = $payment['STATUSID'];

        if ($old_info = $this->getInfoInstance()->getAdditionalInformation('PAYMENT')) {
            $payment = array_merge($old_info, $payment);
        }
        $this->getInfoInstance()->setAdditionalInformation('PAYMENT', $payment);
        $this->getInfoInstance()->setAdditionalInformation('STATUSID', $statusId);

        if (isset($payment['PAYMENTREFERENCE'])) {
            $this->getInfoInstance()->setAdditionalInformation('PAYMENTREFERENCE', $payment['PAYMENTREFERENCE']);
        }

        $this->_responseInsertOrder($payment, $stateObject);


        if (!$stateObject->getState()) {
            $stateObject->getState($this->getOrder()->getState());
            $stateObject->getStatus($this->getOrder()->getStatus());
        }

        Mage::register('payment_redirect_url', $this->getRedirectInfo());
        return $this;
    }

    /**
     * Retrieve order merchant reference for api request
     *
     * @return string
     */
    public function getMerchantReference($force = false)
    {
        if (!$this->getInfoInstance()->getAdditionalInformation('MERCHANTREFERENCE') || $force) {
            $merchantReference = $this->getIncrementId() . '-' . $this->getAttemptId();
            $this->getInfoInstance()->setAdditionalInformation('MERCHANTREFERENCE', $merchantReference);
        }

        return $this->getInfoInstance()->getAdditionalInformation('MERCHANTREFERENCE');
    }

    /**
     * Retrieve order insert attempt number for api request
     *
     * @return int
     */
    public function getAttemptId()
    {
        if (!$this->getInfoInstance()->getAdditionalInformation('attempt_id')) {
            $payment = $this->getInfoInstance()->getAdditionalInformation('PAYMENT');
            $attemptId = isset($payment['ATTEMPTID'])?$payment['ATTEMPTID']:0;
            $this->getInfoInstance()->setAdditionalInformation('attempt_id', $attemptId + 1);
        }

        return $this->getInfoInstance()->getAdditionalInformation('attempt_id');
    }

    /**
     * Increment order insert attempt number for api request
     *
     */
    public function addAttemptId()
    {
        $attempt_id = $this->getInfoInstance()->getAdditionalInformation('attempt_id');
        $this->getInfoInstance()->setAdditionalInformation('attempt_id', $attempt_id + 1);
    }

    /**
     * Check capture availability
     *
     * @return bool
     */
    public function canCapture()
    {
        $available = parent::canCapture();
        if ($available) {
            $statusId = $this->getCurrentStatus();
            if ($statusId <= self::API_STATUS_AUTHORIZED) {
                $available = false;
            }
        }
        return $available;
    }

    /**
     * Capture money from global collect
     *
     * @param Varien_Object $payment
     * @param float $amount
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function capture(Varien_Object $payment, $amount)
    {
        parent::capture($payment, $amount);

        if ($this->getInfoInstance()->getDoNotUpdateStatus()) {
            $statusId = $this->getCurrentStatus();
        } else {
            $statusId = $this->updateStatus();
        }

        if ($statusId == self::API_STATUS_AUTHORIZED) {
            $statusId = $this->settlePayment();
        }

        $transactionId =  $this->getInfoInstance()->getTransactionId();
        if (!$transactionId) {
            $transactionId = $this->getTransactionId();
        }

        if ($statusId >= self::API_STATUS_PAID && $statusId <= self::API_STATUS_COLLECTED) {
            // finish invoice
            $this->getInfoInstance()->setIsTransactionPending(false);
            $this->getInfoInstance()->setTransactionId($transactionId);
            $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);
        } elseif ($statusId >= self::API_STATUS_READY && $statusId < self::API_STATUS_PAID) {
            if ($this->getSelectedPaymentMethod()->isPaymentConfirmationNeeded()
                    && $this->getSelectedPaymentMethod()->isPaymentConfirmationNeeded()) {
                $this->getInfoInstance()->setIsTransactionPending(true);
                $this->_getPayment()->setOrderPending($this->getIncrementId());
            } else {
                $this->getInfoInstance()->setIsTransactionPending(false);
                $this->getInfoInstance()->setTransactionId($transactionId);
                $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);
            }
        } else {
            $this->throwException(Mage::helper('globalcollect')->__('Capture action is not available'));
        }

        return $this;
    }

    /**
     * Void payment authorization
     *
     * @param $payment
     */
    public function void(Varien_Object $payment)
    {
        parent::void($payment);
        // Cancel payment authorization
        $this->cancelPayment();
        return $this;
    }

    /**
     * Retrive transaction id
     *
     * @return string
     */
    public function getTransactionId()
    {
        return $this->getInfoInstance()->getAdditionalInformation('MERCHANTREFERENCE');
        //. '-' . $this->getInfoInstance()->getAdditionalInformation('PAYMENTREFERENCE');
    }

    /**
     * Processing of payment in batch cronjob using GET_ORDERSTATUS API
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function processBatch($expired_atbank = false)
    {
        if ($this->getSelectedPaymentMethod()->isCreditCardOnline()) {
            $newStatus = $this->updateStatus();
            if ($this->getCurrentStatus() == self::API_STATUS_PENDING_GLOBALCOLLECT && $expired_atbank) {
                // after expired period there is no answer
                $this->processCancelOrder();
            }
            return $this;

        } elseif ($this->getCurrentStatus() < self::API_STATUS_PENDING_AT_BANK ) {
            $this->_getPayment()->setOrderPending($this->getIncrementId());
            return $this;
        }

        $newStatus = $this->updateStatus();

        if ($newStatus == self::API_STATUS_PENDING_AT_BANK || $newStatus == self::API_STATUS_PENDING_VERIFICATION){
            if ($expired_atbank) {
                // no status change during expier period
                $this->processCancelOrder();
            }
        } elseif ($newStatus >= self::API_STATUS_READY && $newStatus < self::API_STATUS_PAID) {
            // READY
            $status = $this->getInfoInstance()->getAdditionalInformation('STATUS');
            if ($status['PAYMENTPRODUCTID'] == Smile_Globalcollect_Model_Payment_Product::PRODUCT_BANK_TRANSFER){
                // payment timed out and was set as bank transfer

                if ($this->_getConfig()->getField('pending_email_message_send')) {
                    $this->getOrder()->sendOrderUpdateEmail(true, $this->_getConfig()->getField('pending_email_message'));
                }
                // mark order for WR file checking
                $this->_getPayment()->setOrderPending($this->getIncrementId());
            } else {
                $this->prcessStatusReady($status);
            }
        } elseif ($newStatus >= self::API_STATUS_PAID) {
            // orders that was not processed at READY status or it was offline payment pending at bank

            $this->_getPayment()->addOrderAttempt($this->getIncrementId());
            $this->getInfoInstance()->setDoNotUpdateStatus(true);
            if ($invoice = $this->getPendingInvoice()) {
                $invoice
                    ->capture()
                    ->save();
            } else {
                $this->getInfoInstance()->capture(null);
            }
        } elseif ($expired_atbank || $newStatus < self::API_STATUS_PENDING_AT_BANK ) {
            // mark order for WR file checking
            $this->_getPayment()->setOrderPending($this->getIncrementId());
        }

        return $this;
    }

    /**
     * Processing of payment in batch cronjob using daily report file
     *
     * @param Smile_Globalcollect_Model_Wrfile $wr_data
     * @param bool $expired
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function processWR($wr_data, $expired = false, $test_mode = false)
    {
        $currentStatus = $this->getCurrentStatus();
        $status = $this->getInfoInstance()->getAdditionalInformation('STATUS');

        $processed = false;
        $mode = $test_mode?'test_file_data':'file_data';
        foreach ($wr_data->getData($mode) as $line) {
            // look for flag that indicates payment received
            $status_flag = substr($line, 0, 3);
            $newStatus = $wr_data->checkFlag($status_flag);
            if ($newStatus && (preg_match(
                    "/".$this->getIncrementId()."/",
                    substr($line, $wr_data->getReferencePosition($status_flag), $wr_data->getReferenceLength($status_flag))
                ))
            ) {
                switch ($newStatus) {
                    case Smile_Globalcollect_Model_Wrfile::WR_STATUS_PAID :
                        $this->getInfoInstance()->setDoNotUpdateStatus(true);
                        $this->getInfoInstance()->setAdditionalInformation('STATUSID', self::API_STATUS_PAID);

                        if ($invoice = $this->getPendingInvoice()) {
                            $invoice
                                ->capture()
                                ->save();
                        } else {
                            $this->getInfoInstance()->capture(null);
                        }
//                        $this->getInfoInstance()->capture($this->getPendingInvoice());
                        $processed = true;
                        break;

                    case Smile_Globalcollect_Model_Wrfile::WR_STATUS_CANCEL :
                        $this->processCancelOrder();
                        $processed = true;
                        break;

                    case Smile_Globalcollect_Model_Wrfile::WR_STATUS_REFUNDED :
                        $processed = true;
                        $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);
                        // do nothing. All actions done by Magento at refund create step
                        break;

                    case Smile_Globalcollect_Model_Wrfile::WR_STATUS_REFUND_REJECTED :
                        $processed = true;
                        $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);
                        $creditMemo = $this->getOrder()->getCreditmemosCollection()
                                ->addFieldToFilter('payment_reference', trim(substr(
                                    $line,
                                    $wr_data->getReferencePosition($status_flag),
                                    strpos($line, " ")
                                )))
                                ->getFirstItem();
                        if ($creditMemo->getId()) {
                            $creditMemo->cancel();
                            $this->_saveCreditmemo($creditMemo);
                        }
                        break;

                }
            }

        }

        if ($currentStatus == self::API_STATUS_PENDING_AT_BANK || $currentStatus == self::API_STATUS_PENDING_VERIFICATION
                || ($currentStatus >= self::API_STATUS_READY && $currentStatus < self::API_STATUS_PAID && $status['PAYMENTPRODUCTID'] == Smile_Globalcollect_Model_Payment_Product::PRODUCT_BANK_TRANSFER)
           )
        {
            if (!$processed && $expired) {
                $this->processCancelOrder();
            }
        }
    }

    /**
     * Cleanup pending orders
     *
     * @param type $date
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function processCleanup($date)
    {
        $now = Mage::app()->getLocale()->date(now());

        if ($this->getOrder()->getState() == Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW) {
            $expire = $now->subHour($this->_getConfig()->getField('order_expire_fraud'));

        } else {
            $expire = $now->subHour($this->_getConfig()->getField('order_expire_all'));
        }

        if ($expire->compareDate($date, Varien_Date::DATE_INTERNAL_FORMAT) === 1) {
            if ($this->getOrder()->getState() == Mage_Sales_Model_Order::STATE_PENDING_PAYMENT) {
                $this->processCancelOrder();
            } else {
                $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);
            }
        }

        return $this;
    }

    /**
     * Save token
     *
     * @param array $response
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    protected function _saveToken($payment)
    {
        if ($this->getInfoInstance()->getAdditionalInformation('save_cc_data')
                    && isset($payment['EXPIRYDATE'])
        ) {
            Mage::getModel('globalcollect/token')
                        ->setCustomerId($this->getOrder()->getCustomerId())
                        ->setCcNumber($payment['CREDITCARDNUMBER'])
                        ->setToken($payment['ORDERID'])
                        ->setExpireDate($payment['EXPIRYDATE'])
                        ->setPaymentProductId($payment['PAYMENTMETHODID'])
                        ->save();
        }

        return $this;
    }

    /**
     * Processing orders with status READY
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function prcessStatusReady($payment, $message = "", $session = false)
    {
        if ($this->getSelectedPaymentMethod()->isCreditCardOnline())
        {
            $this->getInfoInstance()->setDoNotUpdateStatus(true);
            $this->getInfoInstance()->capture(null);

            $this->_saveToken($payment);

            $this->_getPayment()->setOrderProcessed($this->getIncrementId());
            
            $this->getOrder()->save();
        } elseif (!$this->getSelectedPaymentMethod()->isPaymentConfirmationNeeded()
                    && !$this->getSelectedPaymentProduct()->isPaymentConfirmationNeeded())
        { // for some methods READY do not mean PAID
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
            if (isset($payment['AMOUNT'])) {
                $message .= " ".Mage::helper('globalcollect')->__("Authorized amount %s", $payment['AMOUNT'] / 100);
            } else {
                $message .= " ".Mage::helper('globalcollect')->__("Authorized payment");
            }

            $this->getOrder()->setState($state, $this->getStatusFromState($state), $message);
            $this->_createInvoice();
            // mark order for WR file checking
            $this->_getPayment()->setOrderPending($this->getIncrementId());
        } else {
            // pending payment already set at initialize() step
            $message .= " ".Mage::helper('globalcollect')->__("Pending customer payment");
            $this->getOrder()->addStatusHistoryComment($message, false);
            if ($session) {
                $session->addNotice(Mage::helper('globalcollect')->__("Your order will be processed after you complete the payment"));
            }
            // mark order for WR file checking
            $this->_getPayment()->setOrderPending($this->getIncrementId());
        }

       return $this;
    }

    /**
     * Cancel order
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function processCancelOrder()
    {
        if (!in_array($this->getOrder()->getState(), array(
            Mage_Sales_Model_Order::STATE_CANCELED,
            Mage_Sales_Model_Order::STATE_CLOSED,
            Mage_Sales_Model_Order::STATE_COMPLETE))
            )
        {
            $this->getOrder()->cancel();

            if (Mage::getModel('globalcollect/config')->getField('cancel_email_message_send')) {
                $this->getOrder()->sendOrderUpdateEmail(true, $this->_getConfig()->getField('cancel_email_message'));
            }
        }
        $this->_getPayment()->setOrderProcessed($this->getIncrementId(), true);

        return $this;
    }


    /**
     * Retrieve pending invoice from order. If no invoice found, return false.
     *
     * @return Mage_Sales_Model_Order_Invoice|boolean
     */
    public function getPendingInvoice()
    {
        /* @var $invoice Mage_Sales_Model_Order_Invoice */
        foreach ($this->getOrder()->getInvoiceCollection() as $invoice) {
            if ($invoice->getState() == Mage_Sales_Model_Order_Invoice::STATE_OPEN /*&& $invoice->getTransactionId() !== null*/) {
                return $invoice;
            }
        }

        return null;
    }


    /**
     * Check is payment fraud challanged
     *
     * @return boolean
     */
    public function isFraudChallenged()
    {
        return $this->getCurrentStatus() == self::API_STATUS_CHALLENGED;
    }

    /**
     * Retrieve order instance
     *
     * @return Mage_Sales_Model_Order
     */
    public function getOrder()
    {
        return $this->getInfoInstance()->getOrder();
    }

    /**
     * Retrive current status id of payment
     *
     * @return int
     */
    public function getCurrentStatus()
    {
        return $this->getInfoInstance()->getAdditionalInformation('STATUSID');
    }

    /**
     * Settles payment in global collect, and returns new order status
     *
     * @return int
     */
    public function settlePayment()
    {
        $response = $this->getApi()->call(Smile_Globalcollect_Model_Api::ACTION_SET_PAYMENT, $this->getOrder());
        if (!$this->isApiResponseSuccessfull($response)) {
            if (!$this->isApiResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Settle payment attempt failed, please try again later'));
            }

            $this->throwException(
                Mage::helper('globalcollect')->__('Settle payment attempt failed')
            );
        }

        $statusId = $this->updateStatus();

        return $statusId;
    }




    /**
     * Cancel settle payment
     *
     * @return int new order status
     */
    public function cancelPayment()
    {
        $response = $this->getApi->call(Smile_Globalcollect_Model_Api::ACTION_CANCEL_PAYMENT, $this->getOrder());

        if (!$this->isApiResponseSuccessfull($response)) {
            if (!$this->isApiResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Cancel payment authorization attempt failed, please try again later'));
            }

            $message = $this->getApiResponseItem($response, 'ERROR');

            $this->throwException(
                Mage::helper('globalcollect')->__('Cancel payment authorization attempt failed: %s', isset($message['MESSAGE'])?$message['MESSAGE']:'')
            );
        }

        $this->_getPayment()->setOrderProcessed($this->getIncrementId());

        return $this;
    }

    /**
     * Cancel payment
     *
     * @param   Varien_Object $invoicePayment
     * @return  Mage_Payment_Model_Abstract
     */
    public function cancel(Varien_Object $payment)
    {
        parent::cancel($payment);

        $this->cancelPayment();
        return $this;
    }

    /**
     * Check void availability,
     * Return false in cases of current method is real time bank transfer,
     * Refund created, payment not authorized anymore
     *
     * @param Varien_Object $payment
     * @return bool
     */
    public function canVoid(Varien_Object $payment)
    {
        return parent::canVoid($payment);
    }


    /**
     * Process return of consumer from thirdparty systems
     *
     * @return int
     */
    public function processReturned()
    {
        if ($this->_getPayment()->isOrderProcessed($this->getIncrementId())) {
            $this->throwException(
                Mage::helper('globalcollect')->__('This order already processed')
            );
        }

        $request = new Varien_Object(array(
            'increment_id' => $this->getIncrementId()
        ));
            if ($this->getSelectedPaymentProduct()->isRealTimeBankTransfer()) {
                $responseKey = 'ROW';
                $action = Smile_Globalcollect_Model_Api::ACTION_PROCESS_RETURNED;

            } else {
                $responseKey = 'STATUS';
                $action = Smile_Globalcollect_Model_Api::ACTION_GET_ORDER_STATUS;
                $payment_info = $this->getInfoInstance()->getAdditionalInformation('PAYMENT');
                if (!empty($payment_info['EFFORTID'])) {
                    $request->setEffortId($payment_info['EFFORTID']);
                }
                if (!empty($payment_info['ORDERID'])) {
                    $request->setIncrementId($payment_info['ORDERID']);
                }
            }
            $response = $this->getApi()->call($action, $request);

            if (!$this->isApiResponseSuccessfull($response)) {
                if (!$this->isApiResponseErrorMessage($response)) {
                    $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
                }

                $this->_getPayment()->setOrderProcessed($this->getIncrementId());
                $this->getOrder()
                    ->cancel()
                    ->save();

                $this->throwException(
                    Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.')
                );
            }

            $message = Mage::helper('globalcollect')->__('Processed user redirection from payment gateway.');

            $responseInfo = $this->getApiResponseItem($response, $responseKey);
            $payment = $this->getInfoInstance()->getAdditionalInformation('PAYMENT');
            $payment = $responseInfo + $payment;

            $statusId = $payment['STATUSID'];
            $this->getInfoInstance()->setAdditionalInformation('PAYMENT', $payment);
            $this->getInfoInstance()->setAdditionalInformation('STATUSID', $statusId);
            if (isset($payment['PAYMENTREFERENCE'])) {
                $this->getInfoInstance()->setAdditionalInformation('PAYMENTREFERENCE', $payment['PAYMENTREFERENCE']);
            }

            $session = Mage::getSingleton('checkout/session');
            if ($statusId == self::API_STATUS_CHALLENGED) {
                $stateObject = null;
                $this->_fraud($stateObject, $session);
            } elseif ($statusId == self::API_STATUS_AUTHORIZED) {
                if ($this->getSelectedPaymentMethod()->isCreditCardOnline()) {
                    $state = Mage_Sales_Model_Order::STATE_PROCESSING;
                    if (isset($payment['AMOUNT'])) {
                        $message .= " ".Mage::helper('globalcollect')->__("Authorized amount of %s", $payment['AMOUNT'] / 100);
                    } else {
                        $message .= " ".Mage::helper('globalcollect')->__("Authorized");
                    }
                    $this->getOrder()->setState($state, $this->getStatusFromState($state), $message);
                    $this->_getPayment()->setOrderProcessed($this->getIncrementId());
                    $mode = $this->_getConfig()->getAuthenticationMode();
                    if ($mode == Smile_Globalcollect_Model_Source_Payment_Action::PAYMENT_ACTION_CAPTURE) {
                        $this->getInfoInstance()->setDoNotUpdateStatus(true);
                        $this->getInfoInstance()->capture(null);
                    } else {
                        $this->_createInvoice();
                    }

                    $this->_saveToken($payment);
                } else {
                    $statusId = $this->settlePayment();
                    if ($statusId == self::API_STATUS_READY) {
                        $this->prcessStatusReady($payment, $message, $session);
                    } else {
                        $message .= " ".Mage::helper('globalcollect')->__("Pending customer payment");
                        $this->getOrder()->addStatusHistoryComment($message, false);
                        // mark order for WR file checking
                        $this->_getPayment()->setOrderPending($this->getIncrementId());
                    }
                }

            } elseif ($statusId == self::API_STATUS_READY) {
                $this->prcessStatusReady($payment, $message, $session);

            } elseif (in_array($statusId, array(
                            self::API_STATUS_PENDING_VERIFICATION,
                            self::API_STATUS_PENDING_AT_BANK,
                            self::API_STATUS_PENDING_BANK,
                            self::API_STATUS_PENDING_CONSUMER
                        ))
                     )
            {
                if ($statusId == self::API_STATUS_PENDING_AT_BANK && $this->getSelectedPaymentMethod()->isCreditCardOnline()) {
                    // 3D secure not passed
                    $this->_getPayment()->setOrderProcessed($this->getIncrementId());
                    $this->getOrder()
                            ->cancel()
                            ->save();
                    $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
                }
                // pending payment
                // pending payment already set at initialize() step
                $message .= " ".Mage::helper('globalcollect')->__("Pending customer payment");
                $this->getOrder()->addStatusHistoryComment($message, false);
                Mage::getSingleton('checkout/session')->addNotice('As soon as your payment is confirmed, your order fulfillment will continue.');
                if ($statusId == self::API_STATUS_PENDING_CONSUMER){
                    // mark order for WR file checking
                    $this->_getPayment()->setOrderPending($this->getIncrementId());
                }
            } else {
                $this->_getPayment()->setOrderProcessed($this->getIncrementId());
                $this->getOrder()
                        ->cancel()
                        ->save();
                $this->throwException(Mage::helper('globalcollect')->__('Unfortunately your payment has failed, please retry.'));
            }

            $this->getOrder()->sendNewOrderEmail();
            $this->getOrder()->save();

        return $statusId;
    }

    /**
     * Manually resolve chalanged payment attempt
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    public function processFraudChallenged()
    {
        $response = $this->getApi()->call(Smile_Globalcollect_Model_Api::ACTION_PROCESS_CHALLENGED, $this);

        if (!$this->isApiResponseSuccessfull($response)) {
            if (!$this->isApiResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Processing challenged payment failed, please try again later'));
            }

            $message = $this->getApiResponseItem($response, 'ERROR');

            $this->throwException(
                Mage::helper('globalcollect')->__('Processing challenged payment failed: %s', $message['MESSAGE'])
            );
        }

        $statusId = $this->updateStatus();

        $this->getOrder()->setState(
            Mage_Sales_Model_Order::STATE_PROCESSING,
            $this->getStatusFromState(Mage_Sales_Model_Order::STATE_PROCESSING),
            Mage::helper('globalcollect')->__('Fraud orfer accepted'),
            false
        );

        if ($statusId == self::API_STATUS_AUTHORIZED) {
            $mode = $this->_getConfig()->getAuthenticationMode();
            if ($mode == Smile_Globalcollect_Model_Source_Payment_Action::PAYMENT_ACTION_CAPTURE) {
                $this->getInfoInstance()->setDoNotUpdateStatus(true);
                $this->getInfoInstance()->capture(null);
            } else {
                $this->_createInvoice();
            }
        } elseif ($statusId >= self::API_STATUS_READY) {
            $this->getInfoInstance()->setDoNotUpdateStatus(true);
            $this->getInfoInstance()->capture(null);
        }

        return $this;
    }

    /**
     * Resolve order status information from global collect,
     * and return current statusId
     *
     * @return int
     */
    public function updateStatus()
    {
        $request = new Varien_Object(array(
            'increment_id' => $this->getIncrementId(),
        ));
        $payment_info = $this->getInfoInstance()->getAdditionalInformation('PAYMENT');
        if (!empty($payment_info['EFFORTID'])) {
            $request->setEffortId($payment_info['EFFORTID']);
        }
        if (!empty($payment_info['ORDERID'])) {
            $request->setIncrementId($payment_info['ORDERID']);
        }

        $response = $this->getApi()->call(Smile_Globalcollect_Model_Api::ACTION_GET_ORDER_STATUS, $request);

        if (!$this->isApiResponseSuccessfull($response)) {
            if (!$this->isApiResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Unable to resolve order status, please try again later'));
            }

            $this->throwException(
                Mage::helper('globalcollect')->__('Unable to resolve order status')
            );
        }

        $status = $this->getApiResponseItem($response, 'STATUS');
        $statusId = $status['STATUSID'];

        $this->getInfoInstance()->setAdditionalInformation('STATUS', $status);
        $this->getInfoInstance()->setAdditionalInformation('STATUSID', $statusId);
        return $statusId;
    }

    /**
     * Mark order as fraud
     *
     * @return Smile_Globalcollect_Model_Method_Abstract
     */
    protected function _fraud(&$stateObject = null, $session = null)
    {
        $state = Mage_Sales_Model_Order::STATE_HOLDED;
        $message = Mage::helper('globalcollect')->__("Fraud suspected! Put on hold");
        if ($stateObject) {
            $stateObject->setState($state);
            $stateObject->setStatus($this->_getConfig()->getField('fraud_order_status'));
            $this->getOrder()->setCustomerNote($message);
        } else {
            $this->getOrder()->setState($state, $this->getStatusFromState($state), $message);
        }

        if ($session) {
            $session->addNotice("As soon as your payment is confirmed, your order fulfillment will continue.");
        }

        return $this;
    }


    /**
     * Redirect url to globalcollect submit form
     *
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
        if ($this->_getPayment()->getCurrentPlacingOrder()) {
            $info = $this->_getPayment()->getCurrentPlacingOrder()->getPayment();
        } else {
            $info = $this->getInfoInstance();
        }

        if ($this->isRedirect() && $info->getAdditionalInformation('is_redirect')) {
            if (Mage::app()->getStore()->isAdmin()) {
                return Mage::helper('adminhtml')->getUrl('adminhtml/globalcollect_method/redirect', array('order_id' => $info->getParentId()));
            }
            return Mage::getUrl('globalcollect/method/redirect', array('order_id' => $info->getParentId()));
        }

        return null;
    }

    /**
     * Retrieve redirection information for current payment product
     *
     * @return boolean|Varien_Object
     */
    public function getRedirectInfo()
    {
        return false;
    }

    /**
     * Thorws global collect exception
     *
     * @param string $message
     * @throws Smile_Globalcollect_Exception
     */
    public function throwException($message)
    {
        throw Mage::exception('Smile_Globalcollect', $message);
    }

    /**
     * Retrive config payment action, globalcollect hasn't, so it just return true
     *
     * @see app/code/core/Mage/Payment/Model/Method/Mage_Payment_Model_Method_Abstract#getConfigPaymentAction()
     */
    public function getConfigPaymentAction()
    {
        return true;
    }

    /**
     *  Save invoice for order
     *
     *  @param    Mage_Sales_Model_Order $order
     *  @return	  boolean Can save invoice or not
     */
    protected function _createInvoice()
    {
        $order = $this->getOrder();
        if ($order->canInvoice()) {
            $convertor = Mage::getModel('sales/convert_order');

            $invoice = $convertor->toInvoice($order);

            foreach ($order->getAllItems() as $orderItem) {
                if (!$orderItem->getQtyToInvoice()) {
                    continue;
                }

                $item = $convertor->itemToInvoiceItem($orderItem);
                $item->setQty($orderItem->getQtyToInvoice());
                $invoice->addItem($item);
            }

            $invoice->collectTotals();
            $invoice->register();

            Mage::getModel('core/resource_transaction')
                    ->addObject($invoice)
                    ->addObject($invoice->getOrder())
                    ->save();

            $order->addStatusHistoryComment(Mage::helper('globalcollect')->__('Invoice %s was created', $invoice->getIncrementId()));
        }

        return false;
    }

    public function is3dSecureEnabled()
    {
        return ($this->_getConfig()->is3dSecureEnabled() && $this->getSelectedPaymentProduct()->is3dSecureAvailable());
    }
    
    public function isPCICompliant()
    {
        return $this->_getConfig()->getField('pci_compliant');
    }

    public function canRefund()
    {
        $canRefund = $this->_canRefund
            && (
                $this->getSelectedPaymentMethod()->canRefund()
                || $this->getSelectedPaymentProduct()->canRefund()
            )
            && in_array($this->getSelectedPaymentProduct()->getId(), $this->_getConfig()->getRefundablePaymentProducts());
        return $canRefund;
    }

    /**
     * Refund payment for online credit card payments
     *
     * @param Varien_Object $payment
     * @param float $amount
     * @return Mage_Payment_Model_Abstract
     */
    public function refund(Varien_Object $payment, $amount)
    {
        $paymentObject = null;
        if ($this->getSelectedPaymentMethod()->getRefundableStatus() !== false) {
            $paymentObject = $this->getSelectedPaymentMethod();
        } elseif ($this->getSelectedPaymentProduct()->getRefundableStatus() !== false) {
            $paymentObject = $this->getSelectedPaymentProduct();
        }

        if (!$paymentObject) {
            $this->throwException(Mage::helper('globalcollect')->__('Payment is not refundable'));
        }

        $statusId = $this->getCurrentStatus();

        if (!$this->getInfoInstance()->getAdditionalInformation('LASTREFUND')) {

            // We should check status if it's not updated before
            if ($statusId < $paymentObject->getRefundableStatus()) {
                $statusId = $this->updateStatus();
            }

            if ($statusId < $paymentObject->getRefundableStatus()) {
                $this->throwException(Mage::helper('globalcollect')->__('Payment is not yet refundable'));
            }
        }

        $newRefund = new Varien_Object(array(
                'amount' => round($amount*100), // amount in cents
                'order_id' => $this->getOrder()->getIncrementId(),
                'merchant_reference' => $this->getMerchantReference(),
                'currency_code' => $this->getOrder()->getBaseCurrencyCode(),
                'payment_product_id' => $this->getSelectedPaymentProduct()->getId()
            ));

        $paymentObject->getAdditionalRefundInfo($newRefund, $this);

        $response = $this->getApi()->call(Smile_Globalcollect_Model_Api::ACTION_DO_REFUND, $newRefund);

        if (!$this->isApiResponseSuccessfull($response)) {
            if (!$this->isApiResponseErrorMessage($response)) {
                $this->throwException(Mage::helper('globalcollect')->__('Refund attempt failed, please try again later'));
            }

            $this->throwException(
                Mage::helper('globalcollect')->__('Refund attempt failed. %s', $this->getApi()->getResponseErrorMessage($response))
            );
        }

        $refund = $this->getApiResponseItem($response, 'ROW');

        if ($refund['STATUSID'] < self::API_STATUS_READY) {
            $this->throwException(
                Mage::helper('globalcollect')->__('Refund attempt failed with status %s', $refund['STATUSID'])
            );
        }

        $this->getInfoInstance()->setAdditionalInformation('LASTREFUND', $refund);


        $refundReference = $refund['PAYMENTREFERENCE'];
        // for CC payment reference is just attempt number!
        // for rest of payments - unique int
        if (strlen($refundReference < 4)) {
            $refundReference = $refund['ADDITIONALREFERENCE'];
        }
        $this->setRefundReference($refundReference);

        // mark order for wr file processing to confirm refund
        $this->_getPayment()->setOrderPending($this->getIncrementId(), true);

        return $this;
    }

    /**
     * Processes creditmemo after refund online started
     *
     * @param Mage_Sales_Model_Order_Creditmemo $creditmemo
     * @param Mage_Sales_Model_Order_Payment $payment
     * @return Mage_Payment_Model_Abstract
     */
    public function processCreditmemo($creditmemo, $payment)
    {
        parent::processCreditmemo($creditmemo, $payment);
        $this->setIsCreditmemoCreated(true);

        $creditmemo->setPaymentReference($this->getRefundReference());
        $this->unsRefundReference();

        return $this;
    }

    /**
     * Save creditmemo and related order, invoice in one transaction
     * @param Mage_Sales_Model_Order_Creditmemo $creditmemo
     */
    protected function _saveCreditmemo($creditmemo)
    {
        $transactionSave = Mage::getModel('core/resource_transaction')
            ->addObject($creditmemo)
            ->addObject($creditmemo->getOrder());
        if ($creditmemo->getInvoice()) {
            $transactionSave->addObject($creditmemo->getInvoice());
        }
        $transactionSave->save();

        return $this;
    }

    /**
     * Prepare refund fields
     *
     * @return array | bool
     */
    public function prepareRefund()
    {
        if ($this->getSelectedPaymentMethod()->canRefund()) {
            return $this->getSelectedPaymentMethod()->prepareRefund($this);
        } elseif ($this->getSelectedPaymentProduct()->canRefund()) {
            return $this->getSelectedPaymentProduct()->prepareRefund($this);
        }
        return false;
    }

    /**
    * Retrieve information from payment configuration
    *
    * @param string $field
    * @param int|string|null|Mage_Core_Model_Store $storeId
    *
    * @return mixed
    */
   public function getModuleConfigData($field, $storeId = null)
   {
       if (null === $storeId) {
           $storeId = $this->getStore();
       }
       $path = 'payment/globalcollect/'.$field;

       return Mage::getStoreConfig($path, $storeId);
   }

}
